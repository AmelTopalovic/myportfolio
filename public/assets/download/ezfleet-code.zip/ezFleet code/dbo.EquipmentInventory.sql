﻿CREATE TABLE [dbo].[EquipmentInventory] (
    [EquipmentID]   INT            IDENTITY (1, 1) NOT NULL,
    [EquipmentType] NVARCHAR (50)  NULL,
    [Vin#]          NVARCHAR (250) NULL,
    [Year]          INT            NULL,
    [Make]          NVARCHAR (50)  NULL,
    [Color]         NVARCHAR (50)  NULL,
    [Mileage]       INT            NULL,
    [PurchaseDate]  DATE           NULL,
    [Unit#]         INT            NOT NULL,
    PRIMARY KEY CLUSTERED ([EquipmentID] ASC)
);

