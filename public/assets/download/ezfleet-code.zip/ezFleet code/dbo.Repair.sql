﻿CREATE TABLE [dbo].[Repair] (
    [RepairID]      INT            NOT NULL IDENTITY,
    [Unit#]           INT NOT NULL,
    [Mileage]         INT             NULL,
    [RepairPerformed] NVARCHAR (MAX)  NULL,
    [ShopInfo]        NVARCHAR (MAX)  NULL,
    [TotalCost]       DECIMAL (18, 2) NULL,
    [Receipt#]        INT             NULL, 
    [RepairDate] DATE NULL, 
    CONSTRAINT [PK_Repair] PRIMARY KEY ([RepairID])
);

