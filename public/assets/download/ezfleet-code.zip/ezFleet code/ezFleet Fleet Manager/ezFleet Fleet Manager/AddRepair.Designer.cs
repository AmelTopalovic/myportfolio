﻿namespace ezFleet_Fleet_Manager
{
    partial class frmAddRepair
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.dtpRepairDate = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.btnAddRepair = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAddRepairPerformed = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAddRepairMileage = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAddRepairTotalCost = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAddRepairReceiptNum = new System.Windows.Forms.TextBox();
            this.txtAddRepairUnitNum = new System.Windows.Forms.TextBox();
            this.txtAddShopInformation = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(12, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 16);
            this.label2.TabIndex = 76;
            this.label2.Text = "Repair Date";
            // 
            // dtpRepairDate
            // 
            this.dtpRepairDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpRepairDate.Location = new System.Drawing.Point(12, 29);
            this.dtpRepairDate.Name = "dtpRepairDate";
            this.dtpRepairDate.Size = new System.Drawing.Size(200, 20);
            this.dtpRepairDate.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(9, 66);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 16);
            this.label9.TabIndex = 73;
            this.label9.Text = "Unit #";
            // 
            // btnAddRepair
            // 
            this.btnAddRepair.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnAddRepair.FlatAppearance.BorderSize = 2;
            this.btnAddRepair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddRepair.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddRepair.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnAddRepair.Location = new System.Drawing.Point(255, 219);
            this.btnAddRepair.Name = "btnAddRepair";
            this.btnAddRepair.Size = new System.Drawing.Size(202, 46);
            this.btnAddRepair.TabIndex = 7;
            this.btnAddRepair.Text = "Add +";
            this.btnAddRepair.UseVisualStyleBackColor = true;
            this.btnAddRepair.Click += new System.EventHandler(this.btnAddRepair_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(12, 177);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 16);
            this.label7.TabIndex = 70;
            this.label7.Text = "Repair Performed";
            // 
            // txtAddRepairPerformed
            // 
            this.txtAddRepairPerformed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddRepairPerformed.Location = new System.Drawing.Point(12, 193);
            this.txtAddRepairPerformed.Multiline = true;
            this.txtAddRepairPerformed.Name = "txtAddRepairPerformed";
            this.txtAddRepairPerformed.Size = new System.Drawing.Size(202, 72);
            this.txtAddRepairPerformed.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 16);
            this.label1.TabIndex = 68;
            this.label1.Text = "Mileage";
            // 
            // txtAddRepairMileage
            // 
            this.txtAddRepairMileage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddRepairMileage.Location = new System.Drawing.Point(12, 144);
            this.txtAddRepairMileage.Name = "txtAddRepairMileage";
            this.txtAddRepairMileage.Size = new System.Drawing.Size(202, 20);
            this.txtAddRepairMileage.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(255, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 16);
            this.label6.TabIndex = 81;
            this.label6.Text = "Shop Information";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(255, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 83;
            this.label3.Text = "Total Cost ($)";
            // 
            // txtAddRepairTotalCost
            // 
            this.txtAddRepairTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddRepairTotalCost.Location = new System.Drawing.Point(255, 193);
            this.txtAddRepairTotalCost.Name = "txtAddRepairTotalCost";
            this.txtAddRepairTotalCost.Size = new System.Drawing.Size(202, 20);
            this.txtAddRepairTotalCost.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(255, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 16);
            this.label4.TabIndex = 85;
            this.label4.Text = "Receipt #";
            // 
            // txtAddRepairReceiptNum
            // 
            this.txtAddRepairReceiptNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddRepairReceiptNum.Location = new System.Drawing.Point(255, 144);
            this.txtAddRepairReceiptNum.Name = "txtAddRepairReceiptNum";
            this.txtAddRepairReceiptNum.Size = new System.Drawing.Size(202, 20);
            this.txtAddRepairReceiptNum.TabIndex = 5;
            // 
            // txtAddRepairUnitNum
            // 
            this.txtAddRepairUnitNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddRepairUnitNum.Location = new System.Drawing.Point(12, 85);
            this.txtAddRepairUnitNum.Name = "txtAddRepairUnitNum";
            this.txtAddRepairUnitNum.Size = new System.Drawing.Size(202, 20);
            this.txtAddRepairUnitNum.TabIndex = 1;
            // 
            // txtAddShopInformation
            // 
            this.txtAddShopInformation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddShopInformation.Location = new System.Drawing.Point(255, 37);
            this.txtAddShopInformation.Multiline = true;
            this.txtAddShopInformation.Name = "txtAddShopInformation";
            this.txtAddShopInformation.Size = new System.Drawing.Size(202, 72);
            this.txtAddShopInformation.TabIndex = 4;
            // 
            // frmAddRepair
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(471, 298);
            this.Controls.Add(this.txtAddShopInformation);
            this.Controls.Add(this.txtAddRepairUnitNum);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtAddRepairReceiptNum);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtAddRepairTotalCost);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpRepairDate);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnAddRepair);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtAddRepairPerformed);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAddRepairMileage);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAddRepair";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add - Repair";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpRepairDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnAddRepair;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAddRepairPerformed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAddRepairMileage;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAddRepairTotalCost;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAddRepairReceiptNum;
        private System.Windows.Forms.TextBox txtAddRepairUnitNum;
        private System.Windows.Forms.TextBox txtAddShopInformation;
    }
}