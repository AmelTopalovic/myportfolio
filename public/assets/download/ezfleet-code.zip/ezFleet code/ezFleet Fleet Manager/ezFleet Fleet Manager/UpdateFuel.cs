﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmUpdateFuel : Form
    {
        private readonly ezFleetDataContext ezFleetDb;

        public frmUpdateFuel(Fuel fuelToUpdate)
        {
            InitializeComponent();

            PreloadFields(fuelToUpdate);

            ezFleetDb = new ezFleetDataContext();
        }

        private void PreloadFields(Fuel fuel)
        {
            lblfuelID.Text = fuel.FuelID.ToString();
            txtUpdateTransactionNum.Text = fuel.TransactionNum.ToString();
            txtUpdateFuelMileage.Text = fuel.Mileage.ToString();
            txtUpdateFuelingLocation.Text = fuel.FuelLocation;
            txtUpdateFuelTotalCost.Text = fuel.TotalCost.ToString();
            txtUpdateGallonsFueled.Text = fuel.GallonsFueled.ToString();
            txtUpdatePricePerGallon.Text = fuel.PricePerGallon.ToString();
            txtUpdateFuelUnitNum.Text = fuel.UnitNum;


        }

        private void btnUpdateFuel_Click(object sender, EventArgs e)
        {
            try
            {
                var fuelID = int.Parse(lblfuelID.Text);
                var fuel = ezFleetDb.Fuels.FirstOrDefault(f => f.FuelID == fuelID);

                fuel.TransactionNum = txtUpdateTransactionNum.Text;
                fuel.UnitNum = txtUpdateFuelUnitNum.Text;
                fuel.FuelDate = DateTime.Parse(dtpFuelDate.Text);
                fuel.FuelLocation = txtUpdateFuelingLocation.Text;
                fuel.PricePerGallon = decimal.Parse(txtUpdatePricePerGallon.Text);
                fuel.GallonsFueled = double.Parse(txtUpdateGallonsFueled.Text);
                fuel.TotalCost = decimal.Parse(txtUpdateFuelTotalCost.Text);
                fuel.Mileage = int.Parse(txtUpdateFuelMileage.Text);

                ezFleetDb.SubmitChanges();
                Close();

                MessageBox.Show("Fuel Record Successfully Updated!");
            }
            catch(FormatException ex)
            {
                MessageBox.Show("Mileage, Total Cost, Gallons Fueled and Price Per Gallon \n fields only accept numbers!");
            }
            {

            }


        }
    }
}
