﻿namespace ezFleet_Fleet_Manager
{
    partial class frmAddMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddMaintenance = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAddEquipmentMileage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAddEquipmentVinNum = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpDateServiced = new System.Windows.Forms.DateTimePicker();
            this.dtpNextServiceDate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAddEquipmentType = new System.Windows.Forms.TextBox();
            this.txtAddUnitNum = new System.Windows.Forms.TextBox();
            this.txtAddServicePerformed = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnAddMaintenance
            // 
            this.btnAddMaintenance.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddMaintenance.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnAddMaintenance.FlatAppearance.BorderSize = 2;
            this.btnAddMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddMaintenance.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMaintenance.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnAddMaintenance.Location = new System.Drawing.Point(254, 179);
            this.btnAddMaintenance.Name = "btnAddMaintenance";
            this.btnAddMaintenance.Size = new System.Drawing.Size(202, 36);
            this.btnAddMaintenance.TabIndex = 6;
            this.btnAddMaintenance.Text = "Add +";
            this.btnAddMaintenance.UseVisualStyleBackColor = true;
            this.btnAddMaintenance.Click += new System.EventHandler(this.btnAddMaintenance_Click);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(12, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 16);
            this.label7.TabIndex = 52;
            this.label7.Text = "Mileage";
            // 
            // txtAddEquipmentMileage
            // 
            this.txtAddEquipmentMileage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddEquipmentMileage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddEquipmentMileage.Location = new System.Drawing.Point(12, 135);
            this.txtAddEquipmentMileage.Name = "txtAddEquipmentMileage";
            this.txtAddEquipmentMileage.Size = new System.Drawing.Size(202, 20);
            this.txtAddEquipmentMileage.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 16);
            this.label1.TabIndex = 46;
            this.label1.Text = "Vin #";
            // 
            // txtAddEquipmentVinNum
            // 
            this.txtAddEquipmentVinNum.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddEquipmentVinNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddEquipmentVinNum.Location = new System.Drawing.Point(12, 86);
            this.txtAddEquipmentVinNum.Name = "txtAddEquipmentVinNum";
            this.txtAddEquipmentVinNum.Size = new System.Drawing.Size(202, 20);
            this.txtAddEquipmentVinNum.TabIndex = 42;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(12, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 16);
            this.label5.TabIndex = 41;
            this.label5.Text = "Equipment Type";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(256, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 16);
            this.label9.TabIndex = 58;
            this.label9.Text = "Unit #";
            // 
            // dtpDateServiced
            // 
            this.dtpDateServiced.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpDateServiced.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateServiced.Location = new System.Drawing.Point(256, 85);
            this.dtpDateServiced.Name = "dtpDateServiced";
            this.dtpDateServiced.Size = new System.Drawing.Size(200, 20);
            this.dtpDateServiced.TabIndex = 4;
            // 
            // dtpNextServiceDate
            // 
            this.dtpNextServiceDate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpNextServiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNextServiceDate.Location = new System.Drawing.Point(256, 135);
            this.dtpNextServiceDate.Name = "dtpNextServiceDate";
            this.dtpNextServiceDate.Size = new System.Drawing.Size(200, 20);
            this.dtpNextServiceDate.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(256, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 61;
            this.label2.Text = "Date Serviced";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(256, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 16);
            this.label3.TabIndex = 62;
            this.label3.Text = "Next Service Date";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(12, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 16);
            this.label4.TabIndex = 64;
            this.label4.Text = "Service Performed";
            // 
            // txtAddEquipmentType
            // 
            this.txtAddEquipmentType.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddEquipmentType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddEquipmentType.Location = new System.Drawing.Point(15, 29);
            this.txtAddEquipmentType.Name = "txtAddEquipmentType";
            this.txtAddEquipmentType.Size = new System.Drawing.Size(202, 20);
            this.txtAddEquipmentType.TabIndex = 0;
            // 
            // txtAddUnitNum
            // 
            this.txtAddUnitNum.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddUnitNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddUnitNum.Location = new System.Drawing.Point(256, 29);
            this.txtAddUnitNum.Name = "txtAddUnitNum";
            this.txtAddUnitNum.Size = new System.Drawing.Size(202, 20);
            this.txtAddUnitNum.TabIndex = 3;
            // 
            // txtAddServicePerformed
            // 
            this.txtAddServicePerformed.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddServicePerformed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddServicePerformed.Location = new System.Drawing.Point(12, 195);
            this.txtAddServicePerformed.Name = "txtAddServicePerformed";
            this.txtAddServicePerformed.Size = new System.Drawing.Size(202, 20);
            this.txtAddServicePerformed.TabIndex = 2;
            // 
            // frmAddMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(473, 248);
            this.Controls.Add(this.txtAddServicePerformed);
            this.Controls.Add(this.txtAddUnitNum);
            this.Controls.Add(this.txtAddEquipmentType);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpNextServiceDate);
            this.Controls.Add(this.dtpDateServiced);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnAddMaintenance);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtAddEquipmentMileage);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAddEquipmentVinNum);
            this.Controls.Add(this.label5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAddMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add - Maintenance";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddMaintenance;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAddEquipmentMileage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAddEquipmentVinNum;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtpDateServiced;
        private System.Windows.Forms.DateTimePicker dtpNextServiceDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAddEquipmentType;
        private System.Windows.Forms.TextBox txtAddUnitNum;
        private System.Windows.Forms.TextBox txtAddServicePerformed;
    }
}