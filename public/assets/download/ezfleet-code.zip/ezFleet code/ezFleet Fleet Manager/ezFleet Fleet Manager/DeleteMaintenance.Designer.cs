﻿namespace ezFleet_Fleet_Manager
{
    partial class frmDeleteMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblError = new System.Windows.Forms.Label();
            this.txtAdminPass = new System.Windows.Forms.TextBox();
            this.btnDelMaintenance = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblError.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblError.ForeColor = System.Drawing.Color.IndianRed;
            this.lblError.Location = new System.Drawing.Point(9, 125);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(0, 16);
            this.lblError.TabIndex = 33;
            // 
            // txtAdminPass
            // 
            this.txtAdminPass.Location = new System.Drawing.Point(12, 28);
            this.txtAdminPass.Name = "txtAdminPass";
            this.txtAdminPass.PasswordChar = '*';
            this.txtAdminPass.Size = new System.Drawing.Size(117, 20);
            this.txtAdminPass.TabIndex = 0;
            this.txtAdminPass.UseSystemPasswordChar = true;
            // 
            // btnDelMaintenance
            // 
            this.btnDelMaintenance.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDelMaintenance.FlatAppearance.BorderSize = 2;
            this.btnDelMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelMaintenance.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelMaintenance.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDelMaintenance.Location = new System.Drawing.Point(12, 66);
            this.btnDelMaintenance.Name = "btnDelMaintenance";
            this.btnDelMaintenance.Size = new System.Drawing.Size(117, 44);
            this.btnDelMaintenance.TabIndex = 1;
            this.btnDelMaintenance.Text = "Delete -";
            this.btnDelMaintenance.UseVisualStyleBackColor = true;
            this.btnDelMaintenance.Click += new System.EventHandler(this.btnDelMaintenance_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(12, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 16);
            this.label5.TabIndex = 30;
            this.label5.Text = "Admin Pin#";
            // 
            // frmDeleteMaintenance
            // 
            this.AcceptButton = this.btnDelMaintenance;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(140, 159);
            this.ControlBox = false;
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.txtAdminPass);
            this.Controls.Add(this.btnDelMaintenance);
            this.Controls.Add(this.label5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDeleteMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Pin";
            this.Load += new System.EventHandler(this.frmDeleteMaintenance_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.TextBox txtAdminPass;
        private System.Windows.Forms.Button btnDelMaintenance;
        private System.Windows.Forms.Label label5;
    }
}