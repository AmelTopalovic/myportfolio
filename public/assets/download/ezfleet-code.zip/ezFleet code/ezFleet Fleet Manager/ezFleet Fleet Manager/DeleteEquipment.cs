﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmDeleteEquipment : Form
    {
        public frmDeleteEquipment()
        {
            InitializeComponent();
        }

        

        private void btnDelEquipment_Click(object sender, EventArgs e)
        {

            string adminPin = "5555";


            if (txtAdminPass.Text.Equals(adminPin))
            {
                Close();

            }
            else
            {
                lblError.Text = "Incorrect Pin";
            }
        }
    }
}
