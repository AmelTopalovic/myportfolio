﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmAddMaintenance : Form
    {
        private readonly ezFleetDataContext ezFleetDb;

        public frmAddMaintenance()
        {
            InitializeComponent();
            ezFleetDb = new ezFleetDataContext();

        }


        private void btnAddMaintenance_Click(object sender, EventArgs e)
        {
            try
            {

                EquipmentMaintenance equipmentMaintenanceAdd = new EquipmentMaintenance
                {
                    UnitNum = txtAddUnitNum.Text,
                    EquipmentType = txtAddEquipmentType.Text,
                    VinNum = txtAddEquipmentVinNum.Text,
                    Mileage = int.Parse(txtAddEquipmentMileage.Text),
                    ServicedPerformed = txtAddServicePerformed.Text,
                    ServiceDate = DateTime.Parse(dtpDateServiced.Text),
                    NextServiceDate = DateTime.Parse(dtpNextServiceDate.Text)

                };
                ezFleetDb.EquipmentMaintenances.InsertOnSubmit(equipmentMaintenanceAdd);
                ezFleetDb.SubmitChanges();
                Close();
                MessageBox.Show("Maintenance Record added");
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Mileage field only accepts numbers!");
            }

        }
    }
}
