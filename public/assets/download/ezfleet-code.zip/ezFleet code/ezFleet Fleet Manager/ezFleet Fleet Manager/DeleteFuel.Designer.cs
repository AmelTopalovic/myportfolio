﻿namespace ezFleet_Fleet_Manager
{
    partial class frmDeleteFuel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDeleteFuel = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAdminPass = new System.Windows.Forms.TextBox();
            this.lblError = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnDeleteFuel
            // 
            this.btnDeleteFuel.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDeleteFuel.FlatAppearance.BorderSize = 2;
            this.btnDeleteFuel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteFuel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteFuel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDeleteFuel.Location = new System.Drawing.Point(9, 54);
            this.btnDeleteFuel.Name = "btnDeleteFuel";
            this.btnDeleteFuel.Size = new System.Drawing.Size(109, 36);
            this.btnDeleteFuel.TabIndex = 1;
            this.btnDeleteFuel.Text = "Delete -";
            this.btnDeleteFuel.UseVisualStyleBackColor = true;
            this.btnDeleteFuel.Click += new System.EventHandler(this.btnDeleteFuel_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(9, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 16);
            this.label9.TabIndex = 106;
            this.label9.Text = "Admin Pin #";
            // 
            // txtAdminPass
            // 
            this.txtAdminPass.Location = new System.Drawing.Point(9, 28);
            this.txtAdminPass.Name = "txtAdminPass";
            this.txtAdminPass.PasswordChar = '*';
            this.txtAdminPass.Size = new System.Drawing.Size(109, 20);
            this.txtAdminPass.TabIndex = 0;
            this.txtAdminPass.UseSystemPasswordChar = true;
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblError.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblError.ForeColor = System.Drawing.Color.IndianRed;
            this.lblError.Location = new System.Drawing.Point(9, 116);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(0, 16);
            this.lblError.TabIndex = 107;
            // 
            // frmDeleteFuel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(138, 150);
            this.ControlBox = false;
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtAdminPass);
            this.Controls.Add(this.btnDeleteFuel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDeleteFuel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Pin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnDeleteFuel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAdminPass;
        private System.Windows.Forms.Label lblError;
    }
}