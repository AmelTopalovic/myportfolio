﻿namespace ezFleet_Fleet_Manager
{
    partial class frmUpdateEquipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpdateEquipment = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMileageUpdate = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtYearUpdate = new System.Windows.Forms.TextBox();
            this.txtMakeUpdate = new System.Windows.Forms.TextBox();
            this.txtColorUpdate = new System.Windows.Forms.TextBox();
            this.txtVinNumUpdate = new System.Windows.Forms.TextBox();
            this.lblEquipmentId = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUnitNumUpdate = new System.Windows.Forms.TextBox();
            this.dtpUpdatePurchaseDate = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // btnUpdateEquipment
            // 
            this.btnUpdateEquipment.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdateEquipment.FlatAppearance.BorderSize = 2;
            this.btnUpdateEquipment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateEquipment.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateEquipment.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdateEquipment.Location = new System.Drawing.Point(255, 203);
            this.btnUpdateEquipment.Name = "btnUpdateEquipment";
            this.btnUpdateEquipment.Size = new System.Drawing.Size(199, 78);
            this.btnUpdateEquipment.TabIndex = 7;
            this.btnUpdateEquipment.Text = "Update";
            this.btnUpdateEquipment.UseVisualStyleBackColor = true;
            this.btnUpdateEquipment.Click += new System.EventHandler(this.btnUpdateEquipment_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(256, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 16);
            this.label6.TabIndex = 53;
            this.label6.Text = "Purchase Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(256, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 16);
            this.label7.TabIndex = 52;
            this.label7.Text = "Mileage";
            // 
            // txtMileageUpdate
            // 
            this.txtMileageUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMileageUpdate.Location = new System.Drawing.Point(256, 26);
            this.txtMileageUpdate.Name = "txtMileageUpdate";
            this.txtMileageUpdate.Size = new System.Drawing.Size(202, 20);
            this.txtMileageUpdate.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(12, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 16);
            this.label4.TabIndex = 49;
            this.label4.Text = "Color";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(12, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 16);
            this.label3.TabIndex = 48;
            this.label3.Text = "Make";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(12, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 16);
            this.label2.TabIndex = 47;
            this.label2.Text = "Year";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 16);
            this.label1.TabIndex = 46;
            this.label1.Text = "Vin #";
            // 
            // txtYearUpdate
            // 
            this.txtYearUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtYearUpdate.Location = new System.Drawing.Point(12, 87);
            this.txtYearUpdate.Name = "txtYearUpdate";
            this.txtYearUpdate.Size = new System.Drawing.Size(202, 20);
            this.txtYearUpdate.TabIndex = 1;
            // 
            // txtMakeUpdate
            // 
            this.txtMakeUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMakeUpdate.Location = new System.Drawing.Point(12, 145);
            this.txtMakeUpdate.Name = "txtMakeUpdate";
            this.txtMakeUpdate.Size = new System.Drawing.Size(202, 20);
            this.txtMakeUpdate.TabIndex = 2;
            // 
            // txtColorUpdate
            // 
            this.txtColorUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtColorUpdate.Location = new System.Drawing.Point(12, 203);
            this.txtColorUpdate.Name = "txtColorUpdate";
            this.txtColorUpdate.Size = new System.Drawing.Size(202, 20);
            this.txtColorUpdate.TabIndex = 3;
            // 
            // txtVinNumUpdate
            // 
            this.txtVinNumUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVinNumUpdate.Location = new System.Drawing.Point(12, 29);
            this.txtVinNumUpdate.Name = "txtVinNumUpdate";
            this.txtVinNumUpdate.Size = new System.Drawing.Size(202, 20);
            this.txtVinNumUpdate.TabIndex = 0;
            // 
            // lblEquipmentId
            // 
            this.lblEquipmentId.AutoSize = true;
            this.lblEquipmentId.Location = new System.Drawing.Point(12, 247);
            this.lblEquipmentId.Name = "lblEquipmentId";
            this.lblEquipmentId.Size = new System.Drawing.Size(0, 13);
            this.lblEquipmentId.TabIndex = 55;
            this.lblEquipmentId.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(255, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 16);
            this.label5.TabIndex = 57;
            this.label5.Text = "Unit #";
            // 
            // txtUnitNumUpdate
            // 
            this.txtUnitNumUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUnitNumUpdate.Location = new System.Drawing.Point(255, 145);
            this.txtUnitNumUpdate.Name = "txtUnitNumUpdate";
            this.txtUnitNumUpdate.Size = new System.Drawing.Size(202, 20);
            this.txtUnitNumUpdate.TabIndex = 6;
            // 
            // dtpUpdatePurchaseDate
            // 
            this.dtpUpdatePurchaseDate.Location = new System.Drawing.Point(256, 86);
            this.dtpUpdatePurchaseDate.Name = "dtpUpdatePurchaseDate";
            this.dtpUpdatePurchaseDate.Size = new System.Drawing.Size(200, 20);
            this.dtpUpdatePurchaseDate.TabIndex = 5;
            // 
            // frmUpdateEquipment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(469, 306);
            this.Controls.Add(this.dtpUpdatePurchaseDate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtUnitNumUpdate);
            this.Controls.Add(this.lblEquipmentId);
            this.Controls.Add(this.btnUpdateEquipment);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtMileageUpdate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtYearUpdate);
            this.Controls.Add(this.txtMakeUpdate);
            this.Controls.Add(this.txtColorUpdate);
            this.Controls.Add(this.txtVinNumUpdate);
            this.Name = "frmUpdateEquipment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update - Equipment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdateEquipment;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMileageUpdate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtYearUpdate;
        private System.Windows.Forms.TextBox txtMakeUpdate;
        private System.Windows.Forms.TextBox txtColorUpdate;
        private System.Windows.Forms.TextBox txtVinNumUpdate;
        private System.Windows.Forms.Label lblEquipmentId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUnitNumUpdate;
        private System.Windows.Forms.DateTimePicker dtpUpdatePurchaseDate;
    }
}