﻿namespace ezFleet_Fleet_Manager
{
    partial class frmAddFuel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.dtpDateFueled = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAddEquipmentMileage = new System.Windows.Forms.TextBox();
            this.txtAddFuelTotalCost = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAddFuelMileage = new System.Windows.Forms.TextBox();
            this.txtAddFuelTransactionNum = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAddFuelLocation = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAddGallonsFueled = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAddPricePerGallon = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnAddFuel = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAddFuelUnitNum = new System.Windows.Forms.TextBox();
            this.lblError = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(11, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = " Date Fueled";
            // 
            // dtpDateFueled
            // 
            this.dtpDateFueled.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateFueled.Location = new System.Drawing.Point(9, 28);
            this.dtpDateFueled.Name = "dtpDateFueled";
            this.dtpDateFueled.Size = new System.Drawing.Size(200, 20);
            this.dtpDateFueled.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(11, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 16);
            this.label7.TabIndex = 70;
            this.label7.Text = "Mileage";
            // 
            // txtAddEquipmentMileage
            // 
            this.txtAddEquipmentMileage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddEquipmentMileage.Location = new System.Drawing.Point(11, 86);
            this.txtAddEquipmentMileage.Name = "txtAddEquipmentMileage";
            this.txtAddEquipmentMileage.Size = new System.Drawing.Size(202, 20);
            this.txtAddEquipmentMileage.TabIndex = 69;
            // 
            // txtAddFuelTotalCost
            // 
            this.txtAddFuelTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddFuelTotalCost.Location = new System.Drawing.Point(11, 143);
            this.txtAddFuelTotalCost.Name = "txtAddFuelTotalCost";
            this.txtAddFuelTotalCost.Size = new System.Drawing.Size(202, 20);
            this.txtAddFuelTotalCost.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(11, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 16);
            this.label1.TabIndex = 70;
            this.label1.Text = "Total Cost (USD)";
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(11, 203);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(202, 20);
            this.textBox2.TabIndex = 69;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(11, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 16);
            this.label3.TabIndex = 70;
            this.label3.Text = "Mileage";
            // 
            // txtAddFuelMileage
            // 
            this.txtAddFuelMileage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddFuelMileage.Location = new System.Drawing.Point(11, 86);
            this.txtAddFuelMileage.Name = "txtAddFuelMileage";
            this.txtAddFuelMileage.Size = new System.Drawing.Size(202, 20);
            this.txtAddFuelMileage.TabIndex = 1;
            // 
            // txtAddFuelTransactionNum
            // 
            this.txtAddFuelTransactionNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddFuelTransactionNum.Location = new System.Drawing.Point(11, 203);
            this.txtAddFuelTransactionNum.Name = "txtAddFuelTransactionNum";
            this.txtAddFuelTransactionNum.Size = new System.Drawing.Size(202, 20);
            this.txtAddFuelTransactionNum.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(11, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 16);
            this.label4.TabIndex = 70;
            this.label4.Text = "Transaction #";
            // 
            // txtAddFuelLocation
            // 
            this.txtAddFuelLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddFuelLocation.Location = new System.Drawing.Point(254, 86);
            this.txtAddFuelLocation.Name = "txtAddFuelLocation";
            this.txtAddFuelLocation.Size = new System.Drawing.Size(202, 20);
            this.txtAddFuelLocation.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(254, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 16);
            this.label5.TabIndex = 70;
            this.label5.Text = "Fueling Location";
            // 
            // txtAddGallonsFueled
            // 
            this.txtAddGallonsFueled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddGallonsFueled.Location = new System.Drawing.Point(254, 143);
            this.txtAddGallonsFueled.Name = "txtAddGallonsFueled";
            this.txtAddGallonsFueled.Size = new System.Drawing.Size(202, 20);
            this.txtAddGallonsFueled.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(254, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 16);
            this.label6.TabIndex = 70;
            this.label6.Text = "Gallons Fueled";
            // 
            // txtAddPricePerGallon
            // 
            this.txtAddPricePerGallon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddPricePerGallon.Location = new System.Drawing.Point(254, 203);
            this.txtAddPricePerGallon.Name = "txtAddPricePerGallon";
            this.txtAddPricePerGallon.Size = new System.Drawing.Size(202, 20);
            this.txtAddPricePerGallon.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Location = new System.Drawing.Point(254, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(151, 16);
            this.label8.TabIndex = 70;
            this.label8.Text = "Price Per Gallon (USD)";
            // 
            // btnAddFuel
            // 
            this.btnAddFuel.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnAddFuel.FlatAppearance.BorderSize = 2;
            this.btnAddFuel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddFuel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddFuel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnAddFuel.Location = new System.Drawing.Point(6, 302);
            this.btnAddFuel.Name = "btnAddFuel";
            this.btnAddFuel.Size = new System.Drawing.Size(452, 36);
            this.btnAddFuel.TabIndex = 8;
            this.btnAddFuel.Text = "Add +";
            this.btnAddFuel.UseVisualStyleBackColor = true;
            this.btnAddFuel.Click += new System.EventHandler(this.btnAddFuel_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(9, 234);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 16);
            this.label9.TabIndex = 79;
            this.label9.Text = "Unit #";
            // 
            // txtAddFuelUnitNum
            // 
            this.txtAddFuelUnitNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddFuelUnitNum.Location = new System.Drawing.Point(9, 250);
            this.txtAddFuelUnitNum.Name = "txtAddFuelUnitNum";
            this.txtAddFuelUnitNum.Size = new System.Drawing.Size(202, 20);
            this.txtAddFuelUnitNum.TabIndex = 4;
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(9, 283);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(0, 13);
            this.lblError.TabIndex = 80;
            // 
            // frmAddFuel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(468, 355);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtAddFuelUnitNum);
            this.Controls.Add(this.btnAddFuel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpDateFueled);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtAddPricePerGallon);
            this.Controls.Add(this.txtAddGallonsFueled);
            this.Controls.Add(this.txtAddFuelLocation);
            this.Controls.Add(this.txtAddFuelTransactionNum);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.txtAddFuelMileage);
            this.Controls.Add(this.txtAddFuelTotalCost);
            this.Controls.Add(this.txtAddEquipmentMileage);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAddFuel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add - Fuel";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpDateFueled;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAddEquipmentMileage;
        private System.Windows.Forms.TextBox txtAddFuelTotalCost;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAddFuelMileage;
        private System.Windows.Forms.TextBox txtAddFuelTransactionNum;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAddFuelLocation;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAddGallonsFueled;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAddPricePerGallon;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnAddFuel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAddFuelUnitNum;
        private System.Windows.Forms.Label lblError;
    }
}