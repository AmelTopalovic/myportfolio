﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmUpdateDriver : Form
    {
        private readonly ezFleetDataContext ezFleetDb;
        public frmUpdateDriver(DriverRosters driverToUpdate)
        {
            InitializeComponent();

            PreloadFields(driverToUpdate);

            ezFleetDb = new ezFleetDataContext();

            
        }

        private void PreloadFields(DriverRosters driver)
        {
            lblrosterId.Text = driver.RosterID.ToString();
            txtDriverNameUpdate.Text = driver.DriverName;
            txtEmailAddressUpdate.Text = driver.EmailAddress;
            txtHomeAddressUpdate.Text = driver.HomeAddress;
            txtPhoneNumberUpdate.Text = driver.PhoneNumber;
            dtpUpdateHireDate.Text = driver.HireDate.ToString();
        }

        private void btnUpdateDriver_Click(object sender, EventArgs e)
        {
            var rosterId = int.Parse(lblrosterId.Text);
            var driver = ezFleetDb.DriverRosters.FirstOrDefault(d => d.RosterID == rosterId);
            driver.DriverName = txtDriverNameUpdate.Text;
            driver.EmailAddress = txtEmailAddressUpdate.Text;
            driver.PhoneNumber = txtPhoneNumberUpdate.Text;
            driver.HomeAddress = txtHomeAddressUpdate.Text;
            driver.HireDate = DateTime.Parse(dtpUpdateHireDate.Text);

            ezFleetDb.SubmitChanges();
            Close();
            MessageBox.Show("Driver Information Successfully Updated!");
           
            
            



        }
    }
}
