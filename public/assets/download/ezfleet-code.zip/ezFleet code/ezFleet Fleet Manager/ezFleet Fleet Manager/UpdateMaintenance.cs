﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmUpdateMaintenance : Form
    {
        private readonly ezFleetDataContext ezFleetDb;
        public frmUpdateMaintenance(EquipmentMaintenance maintenanceToUpdate)
        {
            InitializeComponent();

            PreloadFields(maintenanceToUpdate);

            ezFleetDb = new ezFleetDataContext();
        }

        private void PreloadFields(EquipmentMaintenance maintenance)
        {
            lblMaintenanceID.Text = maintenance.MaintenanceID.ToString();
            txtUpdateMaintenanceMileage.Text = maintenance.Mileage.ToString();
            txtUpdateMaintenanceService.Text = maintenance.ServicedPerformed;
            txtUpdateMaintenanceVinNum.Text = maintenance.VinNum;
            dtpUpdateDateServiced.Text = maintenance.ServiceDate.ToString();
            dtpUpdateNextServiceDate.Text = maintenance.NextServiceDate.ToString();
        }

        private void btnUpdateMaintenance_Click(object sender, EventArgs e)
        {
            try
            {
                var maintenanceID = int.Parse(lblMaintenanceID.Text);
                var maintenance = ezFleetDb.EquipmentMaintenances.FirstOrDefault(m => m.MaintenanceID == maintenanceID);
                maintenance.VinNum = txtUpdateMaintenanceVinNum.Text;
                maintenance.Mileage = int.Parse(txtUpdateMaintenanceMileage.Text);
                maintenance.ServicedPerformed = txtUpdateMaintenanceService.Text;
                maintenance.ServiceDate = dtpUpdateDateServiced.Value;
                maintenance.NextServiceDate = dtpUpdateNextServiceDate.Value;

                ezFleetDb.SubmitChanges();
                Close();
                MessageBox.Show("Maintenance Record Successfully Updated!");
            }
            catch (FormatException ex)
            {
               
                MessageBox.Show("Mileage field only accepts numbers!");
            }
        }
    }
}
