﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmDeleteMaintenance : Form
    {
        public frmDeleteMaintenance()
        {
            InitializeComponent();
        }

        private void frmDeleteMaintenance_Load(object sender, EventArgs e)
        {
            
        }

        private void btnDelMaintenance_Click(object sender, EventArgs e)
        {
            string adminPin = "5555";


            if (txtAdminPass.Text.Equals(adminPin))
            {
                Close();

            }
            else
            {
                lblError.Text = "Incorrect Pin";
            }
        }
    }
}
