﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmUpdateEquipment : Form
    {
        private readonly ezFleetDataContext ezFleetDb;
        public frmUpdateEquipment(EquipmentInventory equipmentToUpdate)
        {
            InitializeComponent();

            PreloadFields(equipmentToUpdate);

            ezFleetDb = new ezFleetDataContext();
        }

        private void PreloadFields(EquipmentInventory equipment)
        {
            lblEquipmentId.Text = equipment.EquipmentID.ToString();
            txtVinNumUpdate.Text = equipment.VinNum;
            txtColorUpdate.Text = equipment.Color;
            txtMakeUpdate.Text = equipment.Make;
            txtMileageUpdate.Text = equipment.Mileage.ToString();
            dtpUpdatePurchaseDate.Text = equipment.PurchaseDate.ToString();
            txtYearUpdate.Text = equipment.Year.ToString();
            txtUnitNumUpdate.Text = equipment.UnitNum.ToString();


        }


        private void btnUpdateEquipment_Click(object sender, EventArgs e)
        {
            try
            {

                var equipmentID = int.Parse(lblEquipmentId.Text);
                var equipment = ezFleetDb.EquipmentInventories.FirstOrDefault(eq => eq.EquipmentID == equipmentID);
                equipment.VinNum = txtVinNumUpdate.Text;
                equipment.Color = txtColorUpdate.Text;
                equipment.Make = txtMakeUpdate.Text;
                equipment.Year = int.Parse(txtYearUpdate.Text);
                equipment.UnitNum = txtUnitNumUpdate.Text;
                equipment.PurchaseDate = DateTime.Parse(dtpUpdatePurchaseDate.Text);
                equipment.Mileage = int.Parse(txtMileageUpdate.Text);

                ezFleetDb.SubmitChanges();
                Close();
                MessageBox.Show("Equipment Successfully Updated!");
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Year and Mileage fields only accept numbers!");
            }
        }
    }
}
