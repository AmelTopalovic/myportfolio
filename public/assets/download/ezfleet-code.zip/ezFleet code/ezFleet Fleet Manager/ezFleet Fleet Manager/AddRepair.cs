﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmAddRepair : Form
    {
        private readonly ezFleetDataContext ezFleetDb;
        public frmAddRepair()
        {
            InitializeComponent();
            ezFleetDb = new ezFleetDataContext();
        }

        private void btnAddRepair_Click(object sender, EventArgs e)
        {
            try
            {
                Repair addRepair = new Repair
                {
                    RepairDate = DateTime.Parse(dtpRepairDate.Text),
                    UnitNum = txtAddRepairUnitNum.Text,
                    Mileage = int.Parse(txtAddRepairMileage.Text),
                    ReceiptNum = txtAddRepairReceiptNum.Text,
                    RepairPerformed = txtAddRepairPerformed.Text,
                    TotalCost = decimal.Parse(txtAddRepairTotalCost.Text),
                    ShopInfo = txtAddShopInformation.Text

                };
                ezFleetDb.Repairs.InsertOnSubmit(addRepair);
                ezFleetDb.SubmitChanges();
                Close();
                MessageBox.Show("Repair Record Added");
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Mileage and Total Cost fields only accept numbers!");
            }
            
        }
    }
}
