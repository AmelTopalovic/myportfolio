﻿namespace ezFleet_Fleet_Manager
{
    partial class frmDeleteDriver
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblError = new System.Windows.Forms.Label();
            this.txtAdminPass = new System.Windows.Forms.TextBox();
            this.btnDeleteDriver = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnDelDriver = new System.Windows.Forms.Button();
            this.txtPinAdmin = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(12, 122);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(100, 23);
            this.lblError.TabIndex = 0;
            // 
            // txtAdminPass
            // 
            this.txtAdminPass.Location = new System.Drawing.Point(0, 0);
            this.txtAdminPass.Name = "txtAdminPass";
            this.txtAdminPass.Size = new System.Drawing.Size(100, 20);
            this.txtAdminPass.TabIndex = 0;
            // 
            // btnDeleteDriver
            // 
            this.btnDeleteDriver.Location = new System.Drawing.Point(0, 0);
            this.btnDeleteDriver.Name = "btnDeleteDriver";
            this.btnDeleteDriver.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteDriver.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 23);
            this.label5.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(9, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 16);
            this.label9.TabIndex = 82;
            this.label9.Text = "Admin Pin #";
            // 
            // btnDelDriver
            // 
            this.btnDelDriver.AutoSize = true;
            this.btnDelDriver.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDelDriver.FlatAppearance.BorderSize = 2;
            this.btnDelDriver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelDriver.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelDriver.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDelDriver.Location = new System.Drawing.Point(12, 60);
            this.btnDelDriver.Name = "btnDelDriver";
            this.btnDelDriver.Size = new System.Drawing.Size(100, 47);
            this.btnDelDriver.TabIndex = 80;
            this.btnDelDriver.Text = "Delete -";
            this.btnDelDriver.UseVisualStyleBackColor = true;
            this.btnDelDriver.Click += new System.EventHandler(this.btnDelDriver_Click);
            // 
            // txtPinAdmin
            // 
            this.txtPinAdmin.Location = new System.Drawing.Point(12, 34);
            this.txtPinAdmin.Name = "txtPinAdmin";
            this.txtPinAdmin.Size = new System.Drawing.Size(100, 20);
            this.txtPinAdmin.TabIndex = 83;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.IndianRed;
            this.label1.Location = new System.Drawing.Point(13, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 16);
            this.label1.TabIndex = 84;
            // 
            // frmDeleteDriver
            // 
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(135, 144);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPinAdmin);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnDelDriver);
            this.Name = "frmDeleteDriver";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Pin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.TextBox txtAdminPass;
        private System.Windows.Forms.Button btnDeleteDriver;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnDelDriver;
        private System.Windows.Forms.TextBox txtPinAdmin;
        private System.Windows.Forms.Label label1;
    }
}