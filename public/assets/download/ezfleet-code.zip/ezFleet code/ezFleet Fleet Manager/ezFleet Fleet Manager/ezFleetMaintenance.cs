﻿namespace ezFleet_Fleet_Manager
{


    public partial class ezFleetMaintenance
    {
    }
}
