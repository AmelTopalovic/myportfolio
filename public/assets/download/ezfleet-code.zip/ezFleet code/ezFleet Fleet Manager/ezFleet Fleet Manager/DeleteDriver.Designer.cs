﻿//namespace ezFleet_Fleet_Manager
//{
//    partial class frmDeleteDrivers
//    {
//        /// <summary>
//        /// Required designer variable.
//        /// </summary>
//        private System.ComponentModel.IContainer components = null;

//        /// <summary>
//        /// Clean up any resources being used.
//        /// </summary>
//        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
//        protected override void Dispose(bool disposing)
//        {
//            if (disposing && (components != null))
//            {
//                components.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        #region Windows Form Designer generated code

//        /// <summary>
//        /// Required method for Designer support - do not modify
//        /// the contents of this method with the code editor.
//        /// </summary>
//        private void InitializeComponent()
//        {
//            this.label5 = new System.Windows.Forms.Label();
//            this.btnDeleteDriver = new System.Windows.Forms.Button();
//            this.txtAdminPass = new System.Windows.Forms.TextBox();
//            this.lblError = new System.Windows.Forms.Label();
//            this.SuspendLayout();
//            // 
//            // label5
//            // 
//            this.label5.AutoSize = true;
//            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
//            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
//            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
//            this.label5.Location = new System.Drawing.Point(12, 13);
//            this.label5.Name = "label5";
//            this.label5.Size = new System.Drawing.Size(118, 16);
//            this.label5.TabIndex = 23;
//            this.label5.Text = "Enter Admin PIN#";
//            // 
//            // btnDeleteDriver
//            // 
//            this.btnDeleteDriver.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
//            this.btnDeleteDriver.FlatAppearance.BorderSize = 2;
//            this.btnDeleteDriver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
//            this.btnDeleteDriver.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
//            this.btnDeleteDriver.ForeColor = System.Drawing.SystemColors.ButtonFace;
//            this.btnDeleteDriver.Location = new System.Drawing.Point(12, 58);
//            this.btnDeleteDriver.Name = "btnDeleteDriver";
//            this.btnDeleteDriver.Size = new System.Drawing.Size(118, 45);
//            this.btnDeleteDriver.TabIndex = 24;
//            this.btnDeleteDriver.Text = "Delete -";
//            this.btnDeleteDriver.UseVisualStyleBackColor = true;
//            this.btnDeleteDriver.Click += new System.EventHandler(this.btnDeleteDriver_Click);
//            // 
//            // txtAdminPass
//            // 
//            this.txtAdminPass.Location = new System.Drawing.Point(12, 32);
//            this.txtAdminPass.Name = "txtAdminPass";
//            this.txtAdminPass.Size = new System.Drawing.Size(118, 20);
//            this.txtAdminPass.TabIndex = 25;
//            // 
//            // lblError
//            // 
//            this.lblError.AutoSize = true;
//            this.lblError.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
//            this.lblError.ForeColor = System.Drawing.Color.Red;
//            this.lblError.Location = new System.Drawing.Point(12, 126);
//            this.lblError.Name = "lblError";
//            this.lblError.Size = new System.Drawing.Size(0, 13);
//            this.lblError.TabIndex = 26;
//            // 
//            // frmDeleteDrivers
//            // 
//            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
//            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
//            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
//            this.ClientSize = new System.Drawing.Size(147, 145);
//            this.Controls.Add(this.lblError);
//            this.Controls.Add(this.txtAdminPass);
//            this.Controls.Add(this.btnDeleteDriver);
//            this.Controls.Add(this.label5);
//            this.MaximizeBox = false;
//            this.MinimizeBox = false;
//            this.Name = "frmDeleteDrivers";
//            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
//            this.Text = "Delete - Driver";
//            this.ResumeLayout(false);
//            this.PerformLayout();

//        }

//        #endregion

//        private System.Windows.Forms.Label label5;
//        private System.Windows.Forms.Button btnDeleteDriver;
//        private System.Windows.Forms.TextBox txtAdminPass;
//        private System.Windows.Forms.Label lblError;
//    }
//}