﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmUpdateRepair : Form
    {
        private readonly ezFleetDataContext ezFleetDb;
        public frmUpdateRepair(Repair repairToUpdate)
        {
            InitializeComponent();
            PreloadFields(repairToUpdate);

            ezFleetDb = new ezFleetDataContext();


        }

        private void PreloadFields(Repair repair)
        {
            lblRepairID.Text = repair.RepairID.ToString();
            txtUpdateRepairReceipt.Text = repair.ReceiptNum.ToString();
            txtUpdateRepairMileage.Text = repair.Mileage.ToString();
            txtUpdateRepairPerformed.Text = repair.RepairPerformed;
            txtUpdateShopInformation.Text = repair.ShopInfo;
            txtUpdateRepairTotalCost.Text = repair.TotalCost.ToString();
            txtUpdateRepairUnitNum.Text = repair.UnitNum.ToString();
            dtpUpdateRepairDate.Text = repair.RepairDate.ToString();
        }

        private void btnUpdateRepair_Click(object sender, EventArgs e)
        {
            try
            {

                var repairID = int.Parse(lblRepairID.Text);
                var repair = ezFleetDb.Repairs.FirstOrDefault(r => r.RepairID == repairID);

                repair.ReceiptNum = txtUpdateRepairReceipt.Text;
                repair.RepairDate = dtpUpdateRepairDate.Value;
                repair.Mileage = int.Parse(txtUpdateRepairMileage.Text);
                repair.RepairPerformed = txtUpdateRepairPerformed.Text;
                repair.ShopInfo = txtUpdateShopInformation.Text;
                repair.UnitNum = txtUpdateRepairUnitNum.Text;
                repair.TotalCost = decimal.Parse(txtUpdateRepairTotalCost.Text);

                ezFleetDb.SubmitChanges();
                Close();
                MessageBox.Show("Repair Record Successfully Updated!");
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Mileage and Total Cost fields only accept numbers!");
            }



        }
    }
}
