﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmEzFleetLogin : Form
    {
       

        string[] loginUserName = new string[3];
        string[] loginPassword = new string[3];
        int foundUserPosition = -1;


        public frmEzFleetLogin()
        {
            InitializeComponent();

            
            loginUserName[0] = "atopalovic";
            loginUserName[1] = "jdoe";
            loginUserName[2] = "egudmestad";

            loginPassword[0] = "admin";
            loginPassword[1] = "reguser";
            loginPassword[2] = "ilovechess";


        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            string userName = txtUsername.Text;
            string password = txtPassword.Text;
            bool login = false;
            lblErrorLogin.Text = String.Empty;

            for (int i = 0; i < loginUserName.Length; i++)
            {
                if((loginUserName[i] == userName) && (loginPassword[i] == password))
                {
                    login = true;
                    foundUserPosition = i;
                    frmEzFleetDashboard ezFleet = new frmEzFleetDashboard(userName);
                    ezFleet.MdiParent = this.MdiParent;
                    
                    ezFleet.ShowDialog();
                    Close();


                }
                

            }
            if (!login)
            {
                lblErrorLogin.Text = "User/Password combination invalid!";
            }
            
        }

    }
}
