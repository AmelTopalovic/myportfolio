﻿namespace ezFleet_Fleet_Manager
{
    partial class frmUpdateDriver
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpdateDriver = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtHomeAddressUpdate = new System.Windows.Forms.TextBox();
            this.txtPhoneNumberUpdate = new System.Windows.Forms.TextBox();
            this.txtEmailAddressUpdate = new System.Windows.Forms.TextBox();
            this.txtDriverNameUpdate = new System.Windows.Forms.TextBox();
            this.lblrosterId = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpUpdateHireDate = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // btnUpdateDriver
            // 
            this.btnUpdateDriver.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdateDriver.FlatAppearance.BorderSize = 2;
            this.btnUpdateDriver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateDriver.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDriver.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdateDriver.Location = new System.Drawing.Point(12, 289);
            this.btnUpdateDriver.Name = "btnUpdateDriver";
            this.btnUpdateDriver.Size = new System.Drawing.Size(202, 79);
            this.btnUpdateDriver.TabIndex = 5;
            this.btnUpdateDriver.Text = "Update";
            this.btnUpdateDriver.UseVisualStyleBackColor = true;
            this.btnUpdateDriver.Click += new System.EventHandler(this.btnUpdateDriver_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(12, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 16);
            this.label4.TabIndex = 18;
            this.label4.Text = "Email Address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(12, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "Phone Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(12, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 16);
            this.label2.TabIndex = 16;
            this.label2.Text = "Home Address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 16);
            this.label1.TabIndex = 15;
            this.label1.Text = "Driver Name";
            // 
            // txtHomeAddressUpdate
            // 
            this.txtHomeAddressUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtHomeAddressUpdate.Location = new System.Drawing.Point(12, 96);
            this.txtHomeAddressUpdate.Name = "txtHomeAddressUpdate";
            this.txtHomeAddressUpdate.Size = new System.Drawing.Size(202, 20);
            this.txtHomeAddressUpdate.TabIndex = 1;
            // 
            // txtPhoneNumberUpdate
            // 
            this.txtPhoneNumberUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPhoneNumberUpdate.Location = new System.Drawing.Point(12, 154);
            this.txtPhoneNumberUpdate.Name = "txtPhoneNumberUpdate";
            this.txtPhoneNumberUpdate.Size = new System.Drawing.Size(202, 20);
            this.txtPhoneNumberUpdate.TabIndex = 2;
            // 
            // txtEmailAddressUpdate
            // 
            this.txtEmailAddressUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmailAddressUpdate.Location = new System.Drawing.Point(12, 212);
            this.txtEmailAddressUpdate.Name = "txtEmailAddressUpdate";
            this.txtEmailAddressUpdate.Size = new System.Drawing.Size(202, 20);
            this.txtEmailAddressUpdate.TabIndex = 3;
            // 
            // txtDriverNameUpdate
            // 
            this.txtDriverNameUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDriverNameUpdate.Location = new System.Drawing.Point(12, 38);
            this.txtDriverNameUpdate.Name = "txtDriverNameUpdate";
            this.txtDriverNameUpdate.Size = new System.Drawing.Size(202, 20);
            this.txtDriverNameUpdate.TabIndex = 0;
            // 
            // lblrosterId
            // 
            this.lblrosterId.AutoSize = true;
            this.lblrosterId.Location = new System.Drawing.Point(123, 19);
            this.lblrosterId.Name = "lblrosterId";
            this.lblrosterId.Size = new System.Drawing.Size(0, 13);
            this.lblrosterId.TabIndex = 20;
            this.lblrosterId.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(12, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 16);
            this.label5.TabIndex = 22;
            this.label5.Text = "Hire Date";
            // 
            // dtpUpdateHireDate
            // 
            this.dtpUpdateHireDate.Location = new System.Drawing.Point(15, 263);
            this.dtpUpdateHireDate.Name = "dtpUpdateHireDate";
            this.dtpUpdateHireDate.Size = new System.Drawing.Size(200, 20);
            this.dtpUpdateHireDate.TabIndex = 23;
            // 
            // frmUpdateDriver
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(230, 380);
            this.Controls.Add(this.dtpUpdateHireDate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblrosterId);
            this.Controls.Add(this.btnUpdateDriver);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtHomeAddressUpdate);
            this.Controls.Add(this.txtPhoneNumberUpdate);
            this.Controls.Add(this.txtEmailAddressUpdate);
            this.Controls.Add(this.txtDriverNameUpdate);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmUpdateDriver";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update - Driver";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdateDriver;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtHomeAddressUpdate;
        private System.Windows.Forms.TextBox txtPhoneNumberUpdate;
        private System.Windows.Forms.TextBox txtEmailAddressUpdate;
        private System.Windows.Forms.TextBox txtDriverNameUpdate;
        private System.Windows.Forms.Label lblrosterId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpUpdateHireDate;
    }
}