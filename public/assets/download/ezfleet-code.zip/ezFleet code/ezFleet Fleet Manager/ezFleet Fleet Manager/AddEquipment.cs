﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmAddEquipment : Form
    {
        private readonly ezFleetDataContext ezFleetDb;
        public frmAddEquipment()
        {
            InitializeComponent();
            ezFleetDb = new ezFleetDataContext();
        }

        private void btnAddEquipment_Click(object sender, EventArgs e)
        {
            try
            {


                EquipmentInventory addEquipment = new EquipmentInventory()
                {
                    UnitNum = txtUnitNumAdd.Text,
                    EquipmentType = txtAddEquipmentType.Text,
                    VinNum = txtVinNumAdd.Text,
                    Year = int.Parse(txtYearAdd.Text),
                    Make = txtMakeAdd.Text,
                    Color = txtColorAdd.Text,
                    Mileage = int.Parse(txtMileageAdd.Text),
                    PurchaseDate = DateTime.Parse(dtpAddPurchaseDate.Text),


                };
                ezFleetDb.EquipmentInventories.InsertOnSubmit(addEquipment);
                ezFleetDb.SubmitChanges();

                Close();
                MessageBox.Show("Equipment added to Inventory");

            }
            catch (FormatException ex)
            {
                MessageBox.Show("Year and Mileage fields only accept numbers!");
            }
            
        }
    }
}
