﻿using System;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmAddFuel : Form
    {
        private readonly ezFleetDataContext ezFleetDb;
        public frmAddFuel()
        {
            InitializeComponent();
            ezFleetDb = new ezFleetDataContext();
        }

        private void btnAddFuel_Click(object sender, EventArgs e)
        {
            try
            {
                Fuel addFuel = new Fuel
                {
                    UnitNum = txtAddFuelUnitNum.Text,
                    FuelDate = DateTime.Parse(dtpDateFueled.Text),
                    Mileage = int.Parse(txtAddFuelMileage.Text),
                    TotalCost = decimal.Parse(txtAddFuelTotalCost.Text),
                    TransactionNum = txtAddFuelTransactionNum.Text,
                    FuelLocation = txtAddFuelLocation.Text,
                    GallonsFueled = double.Parse(txtAddGallonsFueled.Text),
                    PricePerGallon = decimal.Parse(txtAddPricePerGallon.Text)
                };
                ezFleetDb.Fuels.InsertOnSubmit(addFuel);
                ezFleetDb.SubmitChanges();
                Close();
                MessageBox.Show("Fuel Record added");
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Mileage, Total Cost, Gallons Fueled, and Price Per Gallon fields \n only accept numbers!");
            }
        }
    }
}
