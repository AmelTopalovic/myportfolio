﻿namespace ezFleet_Fleet_Manager
{
    partial class frmUpdateFuel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpdateFuel = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtUpdatePricePerGallon = new System.Windows.Forms.TextBox();
            this.txtUpdateGallonsFueled = new System.Windows.Forms.TextBox();
            this.txtUpdateFuelingLocation = new System.Windows.Forms.TextBox();
            this.txtUpdateFuelMileage = new System.Windows.Forms.TextBox();
            this.txtUpdateFuelTotalCost = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblfuelID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUpdateFuelUnitNum = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpFuelDate = new System.Windows.Forms.DateTimePicker();
            this.txtUpdateTransactionNum = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnUpdateFuel
            // 
            this.btnUpdateFuel.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdateFuel.FlatAppearance.BorderSize = 2;
            this.btnUpdateFuel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateFuel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateFuel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdateFuel.Location = new System.Drawing.Point(6, 219);
            this.btnUpdateFuel.Name = "btnUpdateFuel";
            this.btnUpdateFuel.Size = new System.Drawing.Size(452, 36);
            this.btnUpdateFuel.TabIndex = 8;
            this.btnUpdateFuel.Text = "Update";
            this.btnUpdateFuel.UseVisualStyleBackColor = true;
            this.btnUpdateFuel.Click += new System.EventHandler(this.btnUpdateFuel_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Location = new System.Drawing.Point(259, 114);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(151, 16);
            this.label8.TabIndex = 91;
            this.label8.Text = "Price Per Gallon (USD)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(259, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 16);
            this.label6.TabIndex = 90;
            this.label6.Text = "Gallons Fueled";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(259, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 16);
            this.label5.TabIndex = 89;
            this.label5.Text = "Fueling Location";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Total Cost (USD)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(12, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "Mileage";
            // 
            // txtUpdatePricePerGallon
            // 
            this.txtUpdatePricePerGallon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdatePricePerGallon.Location = new System.Drawing.Point(263, 130);
            this.txtUpdatePricePerGallon.Name = "txtUpdatePricePerGallon";
            this.txtUpdatePricePerGallon.Size = new System.Drawing.Size(202, 20);
            this.txtUpdatePricePerGallon.TabIndex = 6;
            // 
            // txtUpdateGallonsFueled
            // 
            this.txtUpdateGallonsFueled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateGallonsFueled.Location = new System.Drawing.Point(262, 77);
            this.txtUpdateGallonsFueled.Name = "txtUpdateGallonsFueled";
            this.txtUpdateGallonsFueled.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateGallonsFueled.TabIndex = 5;
            // 
            // txtUpdateFuelingLocation
            // 
            this.txtUpdateFuelingLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateFuelingLocation.Location = new System.Drawing.Point(262, 28);
            this.txtUpdateFuelingLocation.Name = "txtUpdateFuelingLocation";
            this.txtUpdateFuelingLocation.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateFuelingLocation.TabIndex = 4;
            // 
            // txtUpdateFuelMileage
            // 
            this.txtUpdateFuelMileage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateFuelMileage.Location = new System.Drawing.Point(12, 77);
            this.txtUpdateFuelMileage.Name = "txtUpdateFuelMileage";
            this.txtUpdateFuelMileage.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateFuelMileage.TabIndex = 1;
            // 
            // txtUpdateFuelTotalCost
            // 
            this.txtUpdateFuelTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateFuelTotalCost.Location = new System.Drawing.Point(12, 130);
            this.txtUpdateFuelTotalCost.Name = "txtUpdateFuelTotalCost";
            this.txtUpdateFuelTotalCost.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateFuelTotalCost.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Location = new System.Drawing.Point(12, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 16);
            this.label10.TabIndex = 17;
            this.label10.Text = "Transaction #";
            // 
            // lblfuelID
            // 
            this.lblfuelID.AutoSize = true;
            this.lblfuelID.Location = new System.Drawing.Point(128, 35);
            this.lblfuelID.Name = "lblfuelID";
            this.lblfuelID.Size = new System.Drawing.Size(0, 13);
            this.lblfuelID.TabIndex = 100;
            this.lblfuelID.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(258, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 102;
            this.label2.Text = "Unit #";
            // 
            // txtUpdateFuelUnitNum
            // 
            this.txtUpdateFuelUnitNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateFuelUnitNum.Location = new System.Drawing.Point(262, 179);
            this.txtUpdateFuelUnitNum.Name = "txtUpdateFuelUnitNum";
            this.txtUpdateFuelUnitNum.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateFuelUnitNum.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(9, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Fuel Date";
            // 
            // dtpFuelDate
            // 
            this.dtpFuelDate.Location = new System.Drawing.Point(11, 179);
            this.dtpFuelDate.Name = "dtpFuelDate";
            this.dtpFuelDate.Size = new System.Drawing.Size(200, 20);
            this.dtpFuelDate.TabIndex = 3;
            // 
            // txtUpdateTransactionNum
            // 
            this.txtUpdateTransactionNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateTransactionNum.Location = new System.Drawing.Point(15, 28);
            this.txtUpdateTransactionNum.Name = "txtUpdateTransactionNum";
            this.txtUpdateTransactionNum.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateTransactionNum.TabIndex = 0;
            // 
            // frmUpdateFuel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(470, 279);
            this.Controls.Add(this.txtUpdateTransactionNum);
            this.Controls.Add(this.dtpFuelDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtUpdateFuelUnitNum);
            this.Controls.Add(this.lblfuelID);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnUpdateFuel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtUpdatePricePerGallon);
            this.Controls.Add(this.txtUpdateGallonsFueled);
            this.Controls.Add(this.txtUpdateFuelingLocation);
            this.Controls.Add(this.txtUpdateFuelMileage);
            this.Controls.Add(this.txtUpdateFuelTotalCost);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmUpdateFuel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update - Fuel";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdateFuel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtUpdatePricePerGallon;
        private System.Windows.Forms.TextBox txtUpdateGallonsFueled;
        private System.Windows.Forms.TextBox txtUpdateFuelingLocation;
        private System.Windows.Forms.TextBox txtUpdateFuelMileage;
        private System.Windows.Forms.TextBox txtUpdateFuelTotalCost;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblfuelID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUpdateFuelUnitNum;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpFuelDate;
        private System.Windows.Forms.TextBox txtUpdateTransactionNum;
    }
}