﻿namespace ezFleet_Fleet_Manager
{
    partial class frmDeleteEquipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDelEquipment = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAdminPass = new System.Windows.Forms.TextBox();
            this.lblError = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnDelEquipment
            // 
            this.btnDelEquipment.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDelEquipment.FlatAppearance.BorderSize = 2;
            this.btnDelEquipment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelEquipment.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelEquipment.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDelEquipment.Location = new System.Drawing.Point(12, 71);
            this.btnDelEquipment.Name = "btnDelEquipment";
            this.btnDelEquipment.Size = new System.Drawing.Size(117, 44);
            this.btnDelEquipment.TabIndex = 1;
            this.btnDelEquipment.Text = "Delete -";
            this.btnDelEquipment.UseVisualStyleBackColor = true;
            this.btnDelEquipment.Click += new System.EventHandler(this.btnDelEquipment_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(12, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 16);
            this.label5.TabIndex = 26;
            this.label5.Text = "Admin Pin#";
            // 
            // txtAdminPass
            // 
            this.txtAdminPass.Location = new System.Drawing.Point(12, 33);
            this.txtAdminPass.Name = "txtAdminPass";
            this.txtAdminPass.PasswordChar = '*';
            this.txtAdminPass.Size = new System.Drawing.Size(117, 20);
            this.txtAdminPass.TabIndex = 0;
            this.txtAdminPass.UseSystemPasswordChar = true;
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblError.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblError.ForeColor = System.Drawing.Color.IndianRed;
            this.lblError.Location = new System.Drawing.Point(9, 130);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(0, 16);
            this.lblError.TabIndex = 29;
            // 
            // frmDeleteEquipment
            // 
            this.AcceptButton = this.btnDelEquipment;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(149, 163);
            this.ControlBox = false;
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.txtAdminPass);
            this.Controls.Add(this.btnDelEquipment);
            this.Controls.Add(this.label5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDeleteEquipment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Pin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDelEquipment;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAdminPass;
        private System.Windows.Forms.Label lblError;
    }
}