﻿using System;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmDeleteDriver : Form
    {
        

        public frmDeleteDriver()
        {
            btnDelDriver.Enabled = false;
            InitializeComponent();

        }

       

        private void btnDelDriver_Click(object sender, EventArgs e)
        {
            string adminPin = "8008135!";

            if (adminPin == btnDelDriver.Text)
            {
                lblError.Text = "Incorrect Admin Pin";
            }
            else
            {
                Close();
            }
        }
    }
}

