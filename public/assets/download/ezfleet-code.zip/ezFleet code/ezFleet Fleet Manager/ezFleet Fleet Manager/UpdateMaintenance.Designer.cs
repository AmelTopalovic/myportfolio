﻿namespace ezFleet_Fleet_Manager
{
    partial class frmUpdateMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpUpdateNextServiceDate = new System.Windows.Forms.DateTimePicker();
            this.dtpUpdateDateServiced = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.btnUpdateMaintenance = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtUpdateMaintenanceMileage = new System.Windows.Forms.TextBox();
            this.txtUpdateMaintenanceService = new System.Windows.Forms.TextBox();
            this.txtUpdateMaintenanceVinNum = new System.Windows.Forms.TextBox();
            this.lblMaintenanceID = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(12, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 16);
            this.label4.TabIndex = 79;
            this.label4.Text = "Service Performed";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(256, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 16);
            this.label3.TabIndex = 77;
            this.label3.Text = "Next Service Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(256, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 76;
            this.label2.Text = "Date Serviced";
            // 
            // dtpUpdateNextServiceDate
            // 
            this.dtpUpdateNextServiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpUpdateNextServiceDate.Location = new System.Drawing.Point(256, 132);
            this.dtpUpdateNextServiceDate.Name = "dtpUpdateNextServiceDate";
            this.dtpUpdateNextServiceDate.Size = new System.Drawing.Size(200, 20);
            this.dtpUpdateNextServiceDate.TabIndex = 4;
            // 
            // dtpUpdateDateServiced
            // 
            this.dtpUpdateDateServiced.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpUpdateDateServiced.Location = new System.Drawing.Point(256, 82);
            this.dtpUpdateDateServiced.Name = "dtpUpdateDateServiced";
            this.dtpUpdateDateServiced.Size = new System.Drawing.Size(200, 20);
            this.dtpUpdateDateServiced.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(12, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 16);
            this.label9.TabIndex = 73;
            this.label9.Text = "Vin #";
            // 
            // btnUpdateMaintenance
            // 
            this.btnUpdateMaintenance.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdateMaintenance.FlatAppearance.BorderSize = 2;
            this.btnUpdateMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateMaintenance.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateMaintenance.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdateMaintenance.Location = new System.Drawing.Point(12, 176);
            this.btnUpdateMaintenance.Name = "btnUpdateMaintenance";
            this.btnUpdateMaintenance.Size = new System.Drawing.Size(444, 36);
            this.btnUpdateMaintenance.TabIndex = 5;
            this.btnUpdateMaintenance.Text = "Update";
            this.btnUpdateMaintenance.UseVisualStyleBackColor = true;
            this.btnUpdateMaintenance.Click += new System.EventHandler(this.btnUpdateMaintenance_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(12, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 16);
            this.label7.TabIndex = 70;
            this.label7.Text = "Mileage";
            // 
            // txtUpdateMaintenanceMileage
            // 
            this.txtUpdateMaintenanceMileage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateMaintenanceMileage.Location = new System.Drawing.Point(12, 82);
            this.txtUpdateMaintenanceMileage.Name = "txtUpdateMaintenanceMileage";
            this.txtUpdateMaintenanceMileage.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateMaintenanceMileage.TabIndex = 1;
            // 
            // txtUpdateMaintenanceService
            // 
            this.txtUpdateMaintenanceService.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateMaintenanceService.Location = new System.Drawing.Point(12, 136);
            this.txtUpdateMaintenanceService.Name = "txtUpdateMaintenanceService";
            this.txtUpdateMaintenanceService.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateMaintenanceService.TabIndex = 2;
            // 
            // txtUpdateMaintenanceVinNum
            // 
            this.txtUpdateMaintenanceVinNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateMaintenanceVinNum.Location = new System.Drawing.Point(12, 28);
            this.txtUpdateMaintenanceVinNum.Name = "txtUpdateMaintenanceVinNum";
            this.txtUpdateMaintenanceVinNum.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateMaintenanceVinNum.TabIndex = 0;
            // 
            // lblMaintenanceID
            // 
            this.lblMaintenanceID.AutoSize = true;
            this.lblMaintenanceID.Location = new System.Drawing.Point(229, 116);
            this.lblMaintenanceID.Name = "lblMaintenanceID";
            this.lblMaintenanceID.Size = new System.Drawing.Size(0, 13);
            this.lblMaintenanceID.TabIndex = 82;
            this.lblMaintenanceID.Visible = false;
            // 
            // frmUpdateMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(463, 223);
            this.Controls.Add(this.lblMaintenanceID);
            this.Controls.Add(this.txtUpdateMaintenanceVinNum);
            this.Controls.Add(this.txtUpdateMaintenanceService);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpUpdateNextServiceDate);
            this.Controls.Add(this.dtpUpdateDateServiced);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnUpdateMaintenance);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtUpdateMaintenanceMileage);
            this.Name = "frmUpdateMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update - Maintenance";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpUpdateNextServiceDate;
        private System.Windows.Forms.DateTimePicker dtpUpdateDateServiced;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnUpdateMaintenance;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtUpdateMaintenanceMileage;
        private System.Windows.Forms.TextBox txtUpdateMaintenanceService;
        private System.Windows.Forms.TextBox txtUpdateMaintenanceVinNum;
        private System.Windows.Forms.Label lblMaintenanceID;
    }
}