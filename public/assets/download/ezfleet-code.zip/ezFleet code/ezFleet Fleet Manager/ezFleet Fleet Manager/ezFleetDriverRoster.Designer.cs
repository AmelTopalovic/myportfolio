﻿namespace ezFleet_Fleet_Manager
{
    partial class frmEzFleetDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblLogo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tcDashboard = new System.Windows.Forms.TabControl();
            this.tpDriverRoster = new System.Windows.Forms.TabPage();
            this.txtSearchDrivers = new System.Windows.Forms.TextBox();
            this.btnAddNewDriverInfo = new System.Windows.Forms.Button();
            this.btnUpdateDriverInfo = new System.Windows.Forms.Button();
            this.btnDeleteDriverInfo = new System.Windows.Forms.Button();
            this.dgDriverRoster = new System.Windows.Forms.DataGridView();
            this.rosterIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driverNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.homeAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hireDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driverRosterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ezFleetRoster = new ezFleet_Fleet_Manager.ezFleetRoster();
            this.tpEquipmentInventory = new System.Windows.Forms.TabPage();
            this.txtSearchInventory = new System.Windows.Forms.TextBox();
            this.dgEquipmentInventory = new System.Windows.Forms.DataGridView();
            this.equipmentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipmentTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.makeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mileageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipmentInventoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ezFleetInventory = new ezFleet_Fleet_Manager.ezFleetInventory();
            this.btnAddNewEquipmentInfo = new System.Windows.Forms.Button();
            this.btnUpdateEquipmentInfo = new System.Windows.Forms.Button();
            this.btnDeleteEquipmentInfo = new System.Windows.Forms.Button();
            this.tpEquipmentMaintenance = new System.Windows.Forms.TabPage();
            this.txtSearchMaintenance = new System.Windows.Forms.TextBox();
            this.btnAddNewMaintenanceInfo = new System.Windows.Forms.Button();
            this.btnUpdateEquipmentMaintenanceInfo = new System.Windows.Forms.Button();
            this.btnDeleteEquipmentMaintenanceInfo = new System.Windows.Forms.Button();
            this.dgEquipmentMaintenace = new System.Windows.Forms.DataGridView();
            this.maintenanceIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VinNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipmentTypeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mileageDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicedPerformedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nextServiceDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipmentMaintenanceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ezFleetMaintenance = new ezFleet_Fleet_Manager.ezFleetMaintenance();
            this.tpFuel = new System.Windows.Forms.TabPage();
            this.txtSearchFuel = new System.Windows.Forms.TextBox();
            this.btnAddNewFuelInfo = new System.Windows.Forms.Button();
            this.btnUpdateFuelInfo = new System.Windows.Forms.Button();
            this.btnDeleteFuelInfo = new System.Windows.Forms.Button();
            this.dgFuel = new System.Windows.Forms.DataGridView();
            this.fuelIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mileageDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fuelDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TransactionNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pricePerGallonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gallonsFueledDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalCostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fuelLocationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fuelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ezFleetFuel = new ezFleet_Fleet_Manager.ezFleetFuel();
            this.tpRepairs = new System.Windows.Forms.TabPage();
            this.txtSearchRepair = new System.Windows.Forms.TextBox();
            this.btnAddNewRepairInfo = new System.Windows.Forms.Button();
            this.btnUpdateRepairInfo = new System.Windows.Forms.Button();
            this.btnDeleteRepairInfo = new System.Windows.Forms.Button();
            this.dgRepairs = new System.Windows.Forms.DataGridView();
            this.RepairID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReceiptNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RepairDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RepairPerformed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ShopInfo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mileageDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalCostDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.repairBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ezFleetRepair = new ezFleet_Fleet_Manager.ezFleetRepair();
            this.lblLoggedInAs = new System.Windows.Forms.Label();
            this.driverRosterTableAdapter = new ezFleet_Fleet_Manager.ezFleetRosterTableAdapters.DriverRosterTableAdapter();
            this.fuelTableAdapter = new ezFleet_Fleet_Manager.ezFleetFuelTableAdapters.FuelTableAdapter();
            this.equipmentMaintenanceTableAdapter = new ezFleet_Fleet_Manager.ezFleetMaintenanceTableAdapters.EquipmentMaintenanceTableAdapter();
            this.equipmentInventoryTableAdapter = new ezFleet_Fleet_Manager.ezFleetInventoryTableAdapters.EquipmentInventoryTableAdapter();
            this.repairTableAdapter = new ezFleet_Fleet_Manager.ezFleetRepairTableAdapters.RepairTableAdapter();
            this.tcDashboard.SuspendLayout();
            this.tpDriverRoster.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDriverRoster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.driverRosterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ezFleetRoster)).BeginInit();
            this.tpEquipmentInventory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgEquipmentInventory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipmentInventoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ezFleetInventory)).BeginInit();
            this.tpEquipmentMaintenance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgEquipmentMaintenace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipmentMaintenanceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ezFleetMaintenance)).BeginInit();
            this.tpFuel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFuel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ezFleetFuel)).BeginInit();
            this.tpRepairs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRepairs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repairBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ezFleetRepair)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLogo
            // 
            this.lblLogo.Font = new System.Drawing.Font("Arial", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogo.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lblLogo.Location = new System.Drawing.Point(637, 9);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblLogo.Size = new System.Drawing.Size(151, 63);
            this.lblLogo.TabIndex = 0;
            this.lblLogo.Text = "ezFleet";
            this.lblLogo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(22, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Logged on as:";
            // 
            // tcDashboard
            // 
            this.tcDashboard.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tcDashboard.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tcDashboard.Controls.Add(this.tpDriverRoster);
            this.tcDashboard.Controls.Add(this.tpEquipmentInventory);
            this.tcDashboard.Controls.Add(this.tpEquipmentMaintenance);
            this.tcDashboard.Controls.Add(this.tpFuel);
            this.tcDashboard.Controls.Add(this.tpRepairs);
            this.tcDashboard.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tcDashboard.Location = new System.Drawing.Point(16, 75);
            this.tcDashboard.Multiline = true;
            this.tcDashboard.Name = "tcDashboard";
            this.tcDashboard.Padding = new System.Drawing.Point(3, 3);
            this.tcDashboard.SelectedIndex = 0;
            this.tcDashboard.Size = new System.Drawing.Size(759, 369);
            this.tcDashboard.TabIndex = 1;
            // 
            // tpDriverRoster
            // 
            this.tpDriverRoster.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tpDriverRoster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tpDriverRoster.Controls.Add(this.txtSearchDrivers);
            this.tpDriverRoster.Controls.Add(this.btnAddNewDriverInfo);
            this.tpDriverRoster.Controls.Add(this.btnUpdateDriverInfo);
            this.tpDriverRoster.Controls.Add(this.btnDeleteDriverInfo);
            this.tpDriverRoster.Controls.Add(this.dgDriverRoster);
            this.tpDriverRoster.ForeColor = System.Drawing.Color.DodgerBlue;
            this.tpDriverRoster.Location = new System.Drawing.Point(4, 29);
            this.tpDriverRoster.Name = "tpDriverRoster";
            this.tpDriverRoster.Padding = new System.Windows.Forms.Padding(3);
            this.tpDriverRoster.Size = new System.Drawing.Size(751, 336);
            this.tpDriverRoster.TabIndex = 0;
            this.tpDriverRoster.Text = "Driver Roster";
            this.tpDriverRoster.UseVisualStyleBackColor = true;
            // 
            // txtSearchDrivers
            // 
            this.txtSearchDrivers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearchDrivers.BackColor = System.Drawing.Color.DodgerBlue;
            this.txtSearchDrivers.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchDrivers.ForeColor = System.Drawing.Color.AliceBlue;
            this.txtSearchDrivers.Location = new System.Drawing.Point(251, 303);
            this.txtSearchDrivers.Name = "txtSearchDrivers";
            this.txtSearchDrivers.Size = new System.Drawing.Size(182, 22);
            this.txtSearchDrivers.TabIndex = 4;
            this.txtSearchDrivers.Text = "Search!";
            this.txtSearchDrivers.TextChanged += new System.EventHandler(this.txtSearchDrivers_TextChanged);
            // 
            // btnAddNewDriverInfo
            // 
            this.btnAddNewDriverInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddNewDriverInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddNewDriverInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnAddNewDriverInfo.FlatAppearance.BorderSize = 2;
            this.btnAddNewDriverInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNewDriverInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewDriverInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnAddNewDriverInfo.Location = new System.Drawing.Point(5, 303);
            this.btnAddNewDriverInfo.Name = "btnAddNewDriverInfo";
            this.btnAddNewDriverInfo.Size = new System.Drawing.Size(78, 25);
            this.btnAddNewDriverInfo.TabIndex = 1;
            this.btnAddNewDriverInfo.Text = "Add New +";
            this.btnAddNewDriverInfo.UseVisualStyleBackColor = false;
            this.btnAddNewDriverInfo.Click += new System.EventHandler(this.btnAddNewDriverInfo_Click);
            // 
            // btnUpdateDriverInfo
            // 
            this.btnUpdateDriverInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdateDriverInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateDriverInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateDriverInfo.FlatAppearance.BorderSize = 2;
            this.btnUpdateDriverInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateDriverInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDriverInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnUpdateDriverInfo.Location = new System.Drawing.Point(86, 303);
            this.btnUpdateDriverInfo.Name = "btnUpdateDriverInfo";
            this.btnUpdateDriverInfo.Size = new System.Drawing.Size(78, 25);
            this.btnUpdateDriverInfo.TabIndex = 2;
            this.btnUpdateDriverInfo.Text = "Update";
            this.btnUpdateDriverInfo.UseVisualStyleBackColor = false;
            this.btnUpdateDriverInfo.Click += new System.EventHandler(this.btnUpdateDriverInfo_Click);
            // 
            // btnDeleteDriverInfo
            // 
            this.btnDeleteDriverInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeleteDriverInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDeleteDriverInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteDriverInfo.FlatAppearance.BorderSize = 2;
            this.btnDeleteDriverInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteDriverInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteDriverInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnDeleteDriverInfo.Location = new System.Drawing.Point(167, 303);
            this.btnDeleteDriverInfo.Name = "btnDeleteDriverInfo";
            this.btnDeleteDriverInfo.Size = new System.Drawing.Size(78, 25);
            this.btnDeleteDriverInfo.TabIndex = 3;
            this.btnDeleteDriverInfo.Text = "Delete -";
            this.btnDeleteDriverInfo.UseVisualStyleBackColor = false;
            this.btnDeleteDriverInfo.Click += new System.EventHandler(this.btnDeleteDriverInfo_Click);
            // 
            // dgDriverRoster
            // 
            this.dgDriverRoster.AllowUserToAddRows = false;
            this.dgDriverRoster.AllowUserToDeleteRows = false;
            this.dgDriverRoster.AllowUserToOrderColumns = true;
            this.dgDriverRoster.AutoGenerateColumns = false;
            this.dgDriverRoster.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgDriverRoster.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDriverRoster.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rosterIDDataGridViewTextBoxColumn,
            this.driverNameDataGridViewTextBoxColumn,
            this.homeAddressDataGridViewTextBoxColumn,
            this.phoneNumberDataGridViewTextBoxColumn,
            this.emailAddressDataGridViewTextBoxColumn,
            this.hireDateDataGridViewTextBoxColumn});
            this.dgDriverRoster.DataSource = this.driverRosterBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgDriverRoster.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgDriverRoster.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgDriverRoster.Location = new System.Drawing.Point(3, 3);
            this.dgDriverRoster.Name = "dgDriverRoster";
            this.dgDriverRoster.ReadOnly = true;
            this.dgDriverRoster.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgDriverRoster.Size = new System.Drawing.Size(744, 294);
            this.dgDriverRoster.TabIndex = 0;
            // 
            // rosterIDDataGridViewTextBoxColumn
            // 
            this.rosterIDDataGridViewTextBoxColumn.DataPropertyName = "RosterID";
            this.rosterIDDataGridViewTextBoxColumn.HeaderText = "RosterID";
            this.rosterIDDataGridViewTextBoxColumn.Name = "rosterIDDataGridViewTextBoxColumn";
            this.rosterIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.rosterIDDataGridViewTextBoxColumn.Width = 91;
            // 
            // driverNameDataGridViewTextBoxColumn
            // 
            this.driverNameDataGridViewTextBoxColumn.DataPropertyName = "DriverName";
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.driverNameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.driverNameDataGridViewTextBoxColumn.HeaderText = "Driver Name";
            this.driverNameDataGridViewTextBoxColumn.Name = "driverNameDataGridViewTextBoxColumn";
            this.driverNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.driverNameDataGridViewTextBoxColumn.Width = 106;
            // 
            // homeAddressDataGridViewTextBoxColumn
            // 
            this.homeAddressDataGridViewTextBoxColumn.DataPropertyName = "HomeAddress";
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.homeAddressDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.homeAddressDataGridViewTextBoxColumn.HeaderText = "Home Address";
            this.homeAddressDataGridViewTextBoxColumn.Name = "homeAddressDataGridViewTextBoxColumn";
            this.homeAddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.homeAddressDataGridViewTextBoxColumn.Width = 118;
            // 
            // phoneNumberDataGridViewTextBoxColumn
            // 
            this.phoneNumberDataGridViewTextBoxColumn.DataPropertyName = "PhoneNumber";
            this.phoneNumberDataGridViewTextBoxColumn.HeaderText = "Phone Number";
            this.phoneNumberDataGridViewTextBoxColumn.Name = "phoneNumberDataGridViewTextBoxColumn";
            this.phoneNumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.phoneNumberDataGridViewTextBoxColumn.Width = 120;
            // 
            // emailAddressDataGridViewTextBoxColumn
            // 
            this.emailAddressDataGridViewTextBoxColumn.DataPropertyName = "EmailAddress";
            this.emailAddressDataGridViewTextBoxColumn.HeaderText = "Email Address";
            this.emailAddressDataGridViewTextBoxColumn.Name = "emailAddressDataGridViewTextBoxColumn";
            this.emailAddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.emailAddressDataGridViewTextBoxColumn.Width = 116;
            // 
            // hireDateDataGridViewTextBoxColumn
            // 
            this.hireDateDataGridViewTextBoxColumn.DataPropertyName = "HireDate";
            this.hireDateDataGridViewTextBoxColumn.HeaderText = "Hire Date";
            this.hireDateDataGridViewTextBoxColumn.Name = "hireDateDataGridViewTextBoxColumn";
            this.hireDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.hireDateDataGridViewTextBoxColumn.Width = 87;
            // 
            // driverRosterBindingSource
            // 
            this.driverRosterBindingSource.DataMember = "DriverRoster";
            this.driverRosterBindingSource.DataSource = this.ezFleetRoster;
            // 
            // ezFleetRoster
            // 
            this.ezFleetRoster.DataSetName = "ezFleetRoster";
            this.ezFleetRoster.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tpEquipmentInventory
            // 
            this.tpEquipmentInventory.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tpEquipmentInventory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tpEquipmentInventory.Controls.Add(this.txtSearchInventory);
            this.tpEquipmentInventory.Controls.Add(this.dgEquipmentInventory);
            this.tpEquipmentInventory.Controls.Add(this.btnAddNewEquipmentInfo);
            this.tpEquipmentInventory.Controls.Add(this.btnUpdateEquipmentInfo);
            this.tpEquipmentInventory.Controls.Add(this.btnDeleteEquipmentInfo);
            this.tpEquipmentInventory.Location = new System.Drawing.Point(4, 29);
            this.tpEquipmentInventory.Name = "tpEquipmentInventory";
            this.tpEquipmentInventory.Padding = new System.Windows.Forms.Padding(3);
            this.tpEquipmentInventory.Size = new System.Drawing.Size(751, 336);
            this.tpEquipmentInventory.TabIndex = 1;
            this.tpEquipmentInventory.Text = "Equipment Inventory";
            this.tpEquipmentInventory.UseVisualStyleBackColor = true;
            // 
            // txtSearchInventory
            // 
            this.txtSearchInventory.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearchInventory.BackColor = System.Drawing.Color.DodgerBlue;
            this.txtSearchInventory.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchInventory.ForeColor = System.Drawing.Color.AliceBlue;
            this.txtSearchInventory.Location = new System.Drawing.Point(252, 301);
            this.txtSearchInventory.Name = "txtSearchInventory";
            this.txtSearchInventory.Size = new System.Drawing.Size(182, 22);
            this.txtSearchInventory.TabIndex = 23;
            this.txtSearchInventory.Text = "Search!";
            this.txtSearchInventory.TextChanged += new System.EventHandler(this.txtSearchInventory_TextChanged);
            // 
            // dgEquipmentInventory
            // 
            this.dgEquipmentInventory.AllowUserToAddRows = false;
            this.dgEquipmentInventory.AllowUserToDeleteRows = false;
            this.dgEquipmentInventory.AllowUserToOrderColumns = true;
            this.dgEquipmentInventory.AutoGenerateColumns = false;
            this.dgEquipmentInventory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgEquipmentInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgEquipmentInventory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.equipmentIDDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn2,
            this.equipmentTypeDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn,
            this.makeDataGridViewTextBoxColumn,
            this.colorDataGridViewTextBoxColumn,
            this.mileageDataGridViewTextBoxColumn,
            this.purchaseDateDataGridViewTextBoxColumn});
            this.dgEquipmentInventory.DataSource = this.equipmentInventoryBindingSource;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgEquipmentInventory.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgEquipmentInventory.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgEquipmentInventory.Location = new System.Drawing.Point(3, 3);
            this.dgEquipmentInventory.Name = "dgEquipmentInventory";
            this.dgEquipmentInventory.ReadOnly = true;
            this.dgEquipmentInventory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgEquipmentInventory.Size = new System.Drawing.Size(740, 292);
            this.dgEquipmentInventory.TabIndex = 1;
            // 
            // equipmentIDDataGridViewTextBoxColumn
            // 
            this.equipmentIDDataGridViewTextBoxColumn.DataPropertyName = "EquipmentID";
            this.equipmentIDDataGridViewTextBoxColumn.HeaderText = "Equipment ID";
            this.equipmentIDDataGridViewTextBoxColumn.Name = "equipmentIDDataGridViewTextBoxColumn";
            this.equipmentIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.equipmentIDDataGridViewTextBoxColumn.Width = 111;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "UnitNum";
            this.dataGridViewTextBoxColumn3.HeaderText = "Unit #";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 58;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "VinNum";
            this.dataGridViewTextBoxColumn2.HeaderText = "Vin #";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 53;
            // 
            // equipmentTypeDataGridViewTextBoxColumn
            // 
            this.equipmentTypeDataGridViewTextBoxColumn.DataPropertyName = "EquipmentType";
            this.equipmentTypeDataGridViewTextBoxColumn.HeaderText = "Equipment Type";
            this.equipmentTypeDataGridViewTextBoxColumn.Name = "equipmentTypeDataGridViewTextBoxColumn";
            this.equipmentTypeDataGridViewTextBoxColumn.ReadOnly = true;
            this.equipmentTypeDataGridViewTextBoxColumn.Width = 126;
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            this.yearDataGridViewTextBoxColumn.ReadOnly = true;
            this.yearDataGridViewTextBoxColumn.Width = 62;
            // 
            // makeDataGridViewTextBoxColumn
            // 
            this.makeDataGridViewTextBoxColumn.DataPropertyName = "Make";
            this.makeDataGridViewTextBoxColumn.HeaderText = "Make";
            this.makeDataGridViewTextBoxColumn.Name = "makeDataGridViewTextBoxColumn";
            this.makeDataGridViewTextBoxColumn.ReadOnly = true;
            this.makeDataGridViewTextBoxColumn.Width = 67;
            // 
            // colorDataGridViewTextBoxColumn
            // 
            this.colorDataGridViewTextBoxColumn.DataPropertyName = "Color";
            this.colorDataGridViewTextBoxColumn.HeaderText = "Color";
            this.colorDataGridViewTextBoxColumn.Name = "colorDataGridViewTextBoxColumn";
            this.colorDataGridViewTextBoxColumn.ReadOnly = true;
            this.colorDataGridViewTextBoxColumn.Width = 68;
            // 
            // mileageDataGridViewTextBoxColumn
            // 
            this.mileageDataGridViewTextBoxColumn.DataPropertyName = "Mileage";
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = null;
            this.mileageDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.mileageDataGridViewTextBoxColumn.HeaderText = "Mileage";
            this.mileageDataGridViewTextBoxColumn.Name = "mileageDataGridViewTextBoxColumn";
            this.mileageDataGridViewTextBoxColumn.ReadOnly = true;
            this.mileageDataGridViewTextBoxColumn.Width = 82;
            // 
            // purchaseDateDataGridViewTextBoxColumn
            // 
            this.purchaseDateDataGridViewTextBoxColumn.DataPropertyName = "PurchaseDate";
            this.purchaseDateDataGridViewTextBoxColumn.HeaderText = "Purchase Date";
            this.purchaseDateDataGridViewTextBoxColumn.Name = "purchaseDateDataGridViewTextBoxColumn";
            this.purchaseDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.purchaseDateDataGridViewTextBoxColumn.Width = 120;
            // 
            // equipmentInventoryBindingSource
            // 
            this.equipmentInventoryBindingSource.DataMember = "EquipmentInventory";
            this.equipmentInventoryBindingSource.DataSource = this.ezFleetInventory;
            // 
            // ezFleetInventory
            // 
            this.ezFleetInventory.DataSetName = "ezFleetInventory";
            this.ezFleetInventory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnAddNewEquipmentInfo
            // 
            this.btnAddNewEquipmentInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddNewEquipmentInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddNewEquipmentInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnAddNewEquipmentInfo.FlatAppearance.BorderSize = 2;
            this.btnAddNewEquipmentInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNewEquipmentInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewEquipmentInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnAddNewEquipmentInfo.Location = new System.Drawing.Point(6, 301);
            this.btnAddNewEquipmentInfo.Name = "btnAddNewEquipmentInfo";
            this.btnAddNewEquipmentInfo.Size = new System.Drawing.Size(78, 25);
            this.btnAddNewEquipmentInfo.TabIndex = 9;
            this.btnAddNewEquipmentInfo.Text = "Add New +";
            this.btnAddNewEquipmentInfo.UseVisualStyleBackColor = false;
            this.btnAddNewEquipmentInfo.Click += new System.EventHandler(this.btnAddNewEquipmentInfo_Click);
            // 
            // btnUpdateEquipmentInfo
            // 
            this.btnUpdateEquipmentInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdateEquipmentInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateEquipmentInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateEquipmentInfo.FlatAppearance.BorderSize = 2;
            this.btnUpdateEquipmentInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateEquipmentInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateEquipmentInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnUpdateEquipmentInfo.Location = new System.Drawing.Point(87, 301);
            this.btnUpdateEquipmentInfo.Name = "btnUpdateEquipmentInfo";
            this.btnUpdateEquipmentInfo.Size = new System.Drawing.Size(78, 25);
            this.btnUpdateEquipmentInfo.TabIndex = 10;
            this.btnUpdateEquipmentInfo.Text = "Update";
            this.btnUpdateEquipmentInfo.UseVisualStyleBackColor = false;
            this.btnUpdateEquipmentInfo.Click += new System.EventHandler(this.btnUpdateEquipmentInfo_Click);
            // 
            // btnDeleteEquipmentInfo
            // 
            this.btnDeleteEquipmentInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeleteEquipmentInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDeleteEquipmentInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteEquipmentInfo.FlatAppearance.BorderSize = 2;
            this.btnDeleteEquipmentInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteEquipmentInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteEquipmentInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnDeleteEquipmentInfo.Location = new System.Drawing.Point(168, 301);
            this.btnDeleteEquipmentInfo.Name = "btnDeleteEquipmentInfo";
            this.btnDeleteEquipmentInfo.Size = new System.Drawing.Size(78, 25);
            this.btnDeleteEquipmentInfo.TabIndex = 11;
            this.btnDeleteEquipmentInfo.Text = "Delete -";
            this.btnDeleteEquipmentInfo.UseVisualStyleBackColor = false;
            this.btnDeleteEquipmentInfo.Click += new System.EventHandler(this.btnDeleteEquipmentInfo_Click);
            // 
            // tpEquipmentMaintenance
            // 
            this.tpEquipmentMaintenance.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tpEquipmentMaintenance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tpEquipmentMaintenance.Controls.Add(this.txtSearchMaintenance);
            this.tpEquipmentMaintenance.Controls.Add(this.btnAddNewMaintenanceInfo);
            this.tpEquipmentMaintenance.Controls.Add(this.btnUpdateEquipmentMaintenanceInfo);
            this.tpEquipmentMaintenance.Controls.Add(this.btnDeleteEquipmentMaintenanceInfo);
            this.tpEquipmentMaintenance.Controls.Add(this.dgEquipmentMaintenace);
            this.tpEquipmentMaintenance.Location = new System.Drawing.Point(4, 29);
            this.tpEquipmentMaintenance.Name = "tpEquipmentMaintenance";
            this.tpEquipmentMaintenance.Size = new System.Drawing.Size(751, 336);
            this.tpEquipmentMaintenance.TabIndex = 5;
            this.tpEquipmentMaintenance.Text = "Equipment Maintenance";
            this.tpEquipmentMaintenance.UseVisualStyleBackColor = true;
            // 
            // txtSearchMaintenance
            // 
            this.txtSearchMaintenance.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearchMaintenance.BackColor = System.Drawing.Color.DodgerBlue;
            this.txtSearchMaintenance.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchMaintenance.ForeColor = System.Drawing.Color.AliceBlue;
            this.txtSearchMaintenance.Location = new System.Drawing.Point(252, 303);
            this.txtSearchMaintenance.Name = "txtSearchMaintenance";
            this.txtSearchMaintenance.Size = new System.Drawing.Size(182, 22);
            this.txtSearchMaintenance.TabIndex = 25;
            this.txtSearchMaintenance.Text = "Search!";
            this.txtSearchMaintenance.TextChanged += new System.EventHandler(this.txtSearchMaintenance_TextChanged);
            // 
            // btnAddNewMaintenanceInfo
            // 
            this.btnAddNewMaintenanceInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddNewMaintenanceInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddNewMaintenanceInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnAddNewMaintenanceInfo.FlatAppearance.BorderSize = 2;
            this.btnAddNewMaintenanceInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNewMaintenanceInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewMaintenanceInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnAddNewMaintenanceInfo.Location = new System.Drawing.Point(6, 303);
            this.btnAddNewMaintenanceInfo.Name = "btnAddNewMaintenanceInfo";
            this.btnAddNewMaintenanceInfo.Size = new System.Drawing.Size(78, 25);
            this.btnAddNewMaintenanceInfo.TabIndex = 17;
            this.btnAddNewMaintenanceInfo.Text = "Add New +";
            this.btnAddNewMaintenanceInfo.UseVisualStyleBackColor = false;
            this.btnAddNewMaintenanceInfo.Click += new System.EventHandler(this.btnAddNewMaintenanceInfo_Click);
            // 
            // btnUpdateEquipmentMaintenanceInfo
            // 
            this.btnUpdateEquipmentMaintenanceInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdateEquipmentMaintenanceInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateEquipmentMaintenanceInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateEquipmentMaintenanceInfo.FlatAppearance.BorderSize = 2;
            this.btnUpdateEquipmentMaintenanceInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateEquipmentMaintenanceInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateEquipmentMaintenanceInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnUpdateEquipmentMaintenanceInfo.Location = new System.Drawing.Point(87, 303);
            this.btnUpdateEquipmentMaintenanceInfo.Name = "btnUpdateEquipmentMaintenanceInfo";
            this.btnUpdateEquipmentMaintenanceInfo.Size = new System.Drawing.Size(78, 25);
            this.btnUpdateEquipmentMaintenanceInfo.TabIndex = 18;
            this.btnUpdateEquipmentMaintenanceInfo.Text = "Update";
            this.btnUpdateEquipmentMaintenanceInfo.UseVisualStyleBackColor = false;
            this.btnUpdateEquipmentMaintenanceInfo.Click += new System.EventHandler(this.btnUpdateEquipmentMaintenanceInfo_Click);
            // 
            // btnDeleteEquipmentMaintenanceInfo
            // 
            this.btnDeleteEquipmentMaintenanceInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeleteEquipmentMaintenanceInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDeleteEquipmentMaintenanceInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteEquipmentMaintenanceInfo.FlatAppearance.BorderSize = 2;
            this.btnDeleteEquipmentMaintenanceInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteEquipmentMaintenanceInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteEquipmentMaintenanceInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnDeleteEquipmentMaintenanceInfo.Location = new System.Drawing.Point(168, 303);
            this.btnDeleteEquipmentMaintenanceInfo.Name = "btnDeleteEquipmentMaintenanceInfo";
            this.btnDeleteEquipmentMaintenanceInfo.Size = new System.Drawing.Size(78, 25);
            this.btnDeleteEquipmentMaintenanceInfo.TabIndex = 19;
            this.btnDeleteEquipmentMaintenanceInfo.Text = "Delete -";
            this.btnDeleteEquipmentMaintenanceInfo.UseVisualStyleBackColor = false;
            this.btnDeleteEquipmentMaintenanceInfo.Click += new System.EventHandler(this.btnDeleteEquipmentMaintenanceInfo_Click);
            // 
            // dgEquipmentMaintenace
            // 
            this.dgEquipmentMaintenace.AllowUserToAddRows = false;
            this.dgEquipmentMaintenace.AllowUserToDeleteRows = false;
            this.dgEquipmentMaintenace.AllowUserToOrderColumns = true;
            this.dgEquipmentMaintenace.AutoGenerateColumns = false;
            this.dgEquipmentMaintenace.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgEquipmentMaintenace.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgEquipmentMaintenace.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.maintenanceIDDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn1,
            this.VinNum,
            this.equipmentTypeDataGridViewTextBoxColumn1,
            this.mileageDataGridViewTextBoxColumn1,
            this.servicedPerformedDataGridViewTextBoxColumn,
            this.serviceDateDataGridViewTextBoxColumn,
            this.nextServiceDateDataGridViewTextBoxColumn});
            this.dgEquipmentMaintenace.DataSource = this.equipmentMaintenanceBindingSource;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgEquipmentMaintenace.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgEquipmentMaintenace.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgEquipmentMaintenace.Location = new System.Drawing.Point(3, 3);
            this.dgEquipmentMaintenace.Name = "dgEquipmentMaintenace";
            this.dgEquipmentMaintenace.ReadOnly = true;
            this.dgEquipmentMaintenace.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgEquipmentMaintenace.Size = new System.Drawing.Size(743, 294);
            this.dgEquipmentMaintenace.TabIndex = 1;
            // 
            // maintenanceIDDataGridViewTextBoxColumn
            // 
            this.maintenanceIDDataGridViewTextBoxColumn.DataPropertyName = "MaintenanceID";
            this.maintenanceIDDataGridViewTextBoxColumn.HeaderText = "Maintenance ID";
            this.maintenanceIDDataGridViewTextBoxColumn.Name = "maintenanceIDDataGridViewTextBoxColumn";
            this.maintenanceIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.maintenanceIDDataGridViewTextBoxColumn.Width = 122;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "UnitNum";
            this.dataGridViewTextBoxColumn1.HeaderText = "Unit #";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 58;
            // 
            // VinNum
            // 
            this.VinNum.DataPropertyName = "VinNum";
            this.VinNum.HeaderText = "Vin #";
            this.VinNum.Name = "VinNum";
            this.VinNum.ReadOnly = true;
            this.VinNum.Width = 53;
            // 
            // equipmentTypeDataGridViewTextBoxColumn1
            // 
            this.equipmentTypeDataGridViewTextBoxColumn1.DataPropertyName = "EquipmentType";
            this.equipmentTypeDataGridViewTextBoxColumn1.HeaderText = "Equipment Type";
            this.equipmentTypeDataGridViewTextBoxColumn1.Name = "equipmentTypeDataGridViewTextBoxColumn1";
            this.equipmentTypeDataGridViewTextBoxColumn1.ReadOnly = true;
            this.equipmentTypeDataGridViewTextBoxColumn1.Width = 126;
            // 
            // mileageDataGridViewTextBoxColumn1
            // 
            this.mileageDataGridViewTextBoxColumn1.DataPropertyName = "Mileage";
            this.mileageDataGridViewTextBoxColumn1.HeaderText = "Mileage";
            this.mileageDataGridViewTextBoxColumn1.Name = "mileageDataGridViewTextBoxColumn1";
            this.mileageDataGridViewTextBoxColumn1.ReadOnly = true;
            this.mileageDataGridViewTextBoxColumn1.Width = 82;
            // 
            // servicedPerformedDataGridViewTextBoxColumn
            // 
            this.servicedPerformedDataGridViewTextBoxColumn.DataPropertyName = "ServicedPerformed";
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.servicedPerformedDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.servicedPerformedDataGridViewTextBoxColumn.HeaderText = "Serviced Performed";
            this.servicedPerformedDataGridViewTextBoxColumn.Name = "servicedPerformedDataGridViewTextBoxColumn";
            this.servicedPerformedDataGridViewTextBoxColumn.ReadOnly = true;
            this.servicedPerformedDataGridViewTextBoxColumn.Width = 149;
            // 
            // serviceDateDataGridViewTextBoxColumn
            // 
            this.serviceDateDataGridViewTextBoxColumn.DataPropertyName = "ServiceDate";
            this.serviceDateDataGridViewTextBoxColumn.HeaderText = "Service Date";
            this.serviceDateDataGridViewTextBoxColumn.Name = "serviceDateDataGridViewTextBoxColumn";
            this.serviceDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.serviceDateDataGridViewTextBoxColumn.Width = 107;
            // 
            // nextServiceDateDataGridViewTextBoxColumn
            // 
            this.nextServiceDateDataGridViewTextBoxColumn.DataPropertyName = "NextServiceDate";
            this.nextServiceDateDataGridViewTextBoxColumn.HeaderText = "Next Service Date";
            this.nextServiceDateDataGridViewTextBoxColumn.Name = "nextServiceDateDataGridViewTextBoxColumn";
            this.nextServiceDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.nextServiceDateDataGridViewTextBoxColumn.Width = 137;
            // 
            // equipmentMaintenanceBindingSource
            // 
            this.equipmentMaintenanceBindingSource.DataMember = "EquipmentMaintenance";
            this.equipmentMaintenanceBindingSource.DataSource = this.ezFleetMaintenance;
            // 
            // ezFleetMaintenance
            // 
            this.ezFleetMaintenance.DataSetName = "ezFleetMaintenance";
            this.ezFleetMaintenance.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tpFuel
            // 
            this.tpFuel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tpFuel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tpFuel.Controls.Add(this.txtSearchFuel);
            this.tpFuel.Controls.Add(this.btnAddNewFuelInfo);
            this.tpFuel.Controls.Add(this.btnUpdateFuelInfo);
            this.tpFuel.Controls.Add(this.btnDeleteFuelInfo);
            this.tpFuel.Controls.Add(this.dgFuel);
            this.tpFuel.Location = new System.Drawing.Point(4, 29);
            this.tpFuel.Name = "tpFuel";
            this.tpFuel.Padding = new System.Windows.Forms.Padding(3);
            this.tpFuel.Size = new System.Drawing.Size(751, 336);
            this.tpFuel.TabIndex = 2;
            this.tpFuel.Text = "Fuel";
            this.tpFuel.UseVisualStyleBackColor = true;
            // 
            // txtSearchFuel
            // 
            this.txtSearchFuel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearchFuel.BackColor = System.Drawing.Color.DodgerBlue;
            this.txtSearchFuel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchFuel.ForeColor = System.Drawing.Color.AliceBlue;
            this.txtSearchFuel.Location = new System.Drawing.Point(251, 303);
            this.txtSearchFuel.Name = "txtSearchFuel";
            this.txtSearchFuel.Size = new System.Drawing.Size(182, 22);
            this.txtSearchFuel.TabIndex = 27;
            this.txtSearchFuel.Text = "Search!";
            this.txtSearchFuel.TextChanged += new System.EventHandler(this.txtSearchFuel_TextChanged);
            // 
            // btnAddNewFuelInfo
            // 
            this.btnAddNewFuelInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddNewFuelInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddNewFuelInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnAddNewFuelInfo.FlatAppearance.BorderSize = 2;
            this.btnAddNewFuelInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNewFuelInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewFuelInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnAddNewFuelInfo.Location = new System.Drawing.Point(5, 303);
            this.btnAddNewFuelInfo.Name = "btnAddNewFuelInfo";
            this.btnAddNewFuelInfo.Size = new System.Drawing.Size(78, 25);
            this.btnAddNewFuelInfo.TabIndex = 17;
            this.btnAddNewFuelInfo.Text = "Add New +";
            this.btnAddNewFuelInfo.UseVisualStyleBackColor = false;
            this.btnAddNewFuelInfo.Click += new System.EventHandler(this.btnAddNewFuelInfo_Click);
            // 
            // btnUpdateFuelInfo
            // 
            this.btnUpdateFuelInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdateFuelInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateFuelInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateFuelInfo.FlatAppearance.BorderSize = 2;
            this.btnUpdateFuelInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateFuelInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateFuelInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnUpdateFuelInfo.Location = new System.Drawing.Point(86, 303);
            this.btnUpdateFuelInfo.Name = "btnUpdateFuelInfo";
            this.btnUpdateFuelInfo.Size = new System.Drawing.Size(78, 25);
            this.btnUpdateFuelInfo.TabIndex = 18;
            this.btnUpdateFuelInfo.Text = "Update";
            this.btnUpdateFuelInfo.UseVisualStyleBackColor = false;
            this.btnUpdateFuelInfo.Click += new System.EventHandler(this.btnUpdateFuelInfo_Click);
            // 
            // btnDeleteFuelInfo
            // 
            this.btnDeleteFuelInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeleteFuelInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDeleteFuelInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteFuelInfo.FlatAppearance.BorderSize = 2;
            this.btnDeleteFuelInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteFuelInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteFuelInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnDeleteFuelInfo.Location = new System.Drawing.Point(167, 303);
            this.btnDeleteFuelInfo.Name = "btnDeleteFuelInfo";
            this.btnDeleteFuelInfo.Size = new System.Drawing.Size(78, 25);
            this.btnDeleteFuelInfo.TabIndex = 19;
            this.btnDeleteFuelInfo.Text = "Delete -";
            this.btnDeleteFuelInfo.UseVisualStyleBackColor = false;
            this.btnDeleteFuelInfo.Click += new System.EventHandler(this.btnDeleteFuelInfo_Click);
            // 
            // dgFuel
            // 
            this.dgFuel.AllowUserToAddRows = false;
            this.dgFuel.AllowUserToDeleteRows = false;
            this.dgFuel.AllowUserToOrderColumns = true;
            this.dgFuel.AutoGenerateColumns = false;
            this.dgFuel.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgFuel.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgFuel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgFuel.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fuelIDDataGridViewTextBoxColumn,
            this.UnitNum,
            this.mileageDataGridViewTextBoxColumn2,
            this.fuelDateDataGridViewTextBoxColumn,
            this.TransactionNum,
            this.pricePerGallonDataGridViewTextBoxColumn,
            this.gallonsFueledDataGridViewTextBoxColumn,
            this.totalCostDataGridViewTextBoxColumn,
            this.fuelLocationDataGridViewTextBoxColumn});
            this.dgFuel.DataSource = this.fuelBindingSource;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgFuel.DefaultCellStyle = dataGridViewCellStyle13;
            this.dgFuel.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgFuel.Location = new System.Drawing.Point(3, 3);
            this.dgFuel.Name = "dgFuel";
            this.dgFuel.ReadOnly = true;
            this.dgFuel.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgFuel.Size = new System.Drawing.Size(743, 295);
            this.dgFuel.TabIndex = 1;
            // 
            // fuelIDDataGridViewTextBoxColumn
            // 
            this.fuelIDDataGridViewTextBoxColumn.DataPropertyName = "FuelID";
            this.fuelIDDataGridViewTextBoxColumn.HeaderText = "Fuel ID";
            this.fuelIDDataGridViewTextBoxColumn.Name = "fuelIDDataGridViewTextBoxColumn";
            this.fuelIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.fuelIDDataGridViewTextBoxColumn.Width = 61;
            // 
            // UnitNum
            // 
            this.UnitNum.DataPropertyName = "UnitNum";
            this.UnitNum.HeaderText = "Unit #";
            this.UnitNum.Name = "UnitNum";
            this.UnitNum.ReadOnly = true;
            this.UnitNum.Width = 58;
            // 
            // mileageDataGridViewTextBoxColumn2
            // 
            this.mileageDataGridViewTextBoxColumn2.DataPropertyName = "Mileage";
            dataGridViewCellStyle9.Format = "N0";
            dataGridViewCellStyle9.NullValue = null;
            this.mileageDataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle9;
            this.mileageDataGridViewTextBoxColumn2.HeaderText = "Mileage";
            this.mileageDataGridViewTextBoxColumn2.Name = "mileageDataGridViewTextBoxColumn2";
            this.mileageDataGridViewTextBoxColumn2.ReadOnly = true;
            this.mileageDataGridViewTextBoxColumn2.Width = 82;
            // 
            // fuelDateDataGridViewTextBoxColumn
            // 
            this.fuelDateDataGridViewTextBoxColumn.DataPropertyName = "FuelDate";
            this.fuelDateDataGridViewTextBoxColumn.HeaderText = "Fuel Date";
            this.fuelDateDataGridViewTextBoxColumn.Name = "fuelDateDataGridViewTextBoxColumn";
            this.fuelDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.fuelDateDataGridViewTextBoxColumn.Width = 88;
            // 
            // TransactionNum
            // 
            this.TransactionNum.DataPropertyName = "TransactionNum";
            this.TransactionNum.HeaderText = "Transaction #";
            this.TransactionNum.Name = "TransactionNum";
            this.TransactionNum.ReadOnly = true;
            this.TransactionNum.Width = 111;
            // 
            // pricePerGallonDataGridViewTextBoxColumn
            // 
            this.pricePerGallonDataGridViewTextBoxColumn.DataPropertyName = "PricePerGallon";
            dataGridViewCellStyle10.Format = "C2";
            dataGridViewCellStyle10.NullValue = null;
            this.pricePerGallonDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle10;
            this.pricePerGallonDataGridViewTextBoxColumn.HeaderText = "Price Per Gallon";
            this.pricePerGallonDataGridViewTextBoxColumn.Name = "pricePerGallonDataGridViewTextBoxColumn";
            this.pricePerGallonDataGridViewTextBoxColumn.ReadOnly = true;
            this.pricePerGallonDataGridViewTextBoxColumn.Width = 127;
            // 
            // gallonsFueledDataGridViewTextBoxColumn
            // 
            this.gallonsFueledDataGridViewTextBoxColumn.DataPropertyName = "GallonsFueled";
            this.gallonsFueledDataGridViewTextBoxColumn.HeaderText = "Gallons Fueled";
            this.gallonsFueledDataGridViewTextBoxColumn.Name = "gallonsFueledDataGridViewTextBoxColumn";
            this.gallonsFueledDataGridViewTextBoxColumn.ReadOnly = true;
            this.gallonsFueledDataGridViewTextBoxColumn.Width = 119;
            // 
            // totalCostDataGridViewTextBoxColumn
            // 
            this.totalCostDataGridViewTextBoxColumn.DataPropertyName = "TotalCost";
            dataGridViewCellStyle11.Format = "C2";
            dataGridViewCellStyle11.NullValue = null;
            this.totalCostDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle11;
            this.totalCostDataGridViewTextBoxColumn.HeaderText = "Total Cost";
            this.totalCostDataGridViewTextBoxColumn.Name = "totalCostDataGridViewTextBoxColumn";
            this.totalCostDataGridViewTextBoxColumn.ReadOnly = true;
            this.totalCostDataGridViewTextBoxColumn.Width = 90;
            // 
            // fuelLocationDataGridViewTextBoxColumn
            // 
            this.fuelLocationDataGridViewTextBoxColumn.DataPropertyName = "FuelLocation";
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.fuelLocationDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle12;
            this.fuelLocationDataGridViewTextBoxColumn.HeaderText = "Fuel Location";
            this.fuelLocationDataGridViewTextBoxColumn.Name = "fuelLocationDataGridViewTextBoxColumn";
            this.fuelLocationDataGridViewTextBoxColumn.ReadOnly = true;
            this.fuelLocationDataGridViewTextBoxColumn.Width = 110;
            // 
            // fuelBindingSource
            // 
            this.fuelBindingSource.DataMember = "Fuel";
            this.fuelBindingSource.DataSource = this.ezFleetFuel;
            // 
            // ezFleetFuel
            // 
            this.ezFleetFuel.DataSetName = "ezFleetFuel";
            this.ezFleetFuel.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tpRepairs
            // 
            this.tpRepairs.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tpRepairs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tpRepairs.Controls.Add(this.txtSearchRepair);
            this.tpRepairs.Controls.Add(this.btnAddNewRepairInfo);
            this.tpRepairs.Controls.Add(this.btnUpdateRepairInfo);
            this.tpRepairs.Controls.Add(this.btnDeleteRepairInfo);
            this.tpRepairs.Controls.Add(this.dgRepairs);
            this.tpRepairs.ForeColor = System.Drawing.Color.Black;
            this.tpRepairs.Location = new System.Drawing.Point(4, 29);
            this.tpRepairs.Name = "tpRepairs";
            this.tpRepairs.Padding = new System.Windows.Forms.Padding(3);
            this.tpRepairs.Size = new System.Drawing.Size(751, 336);
            this.tpRepairs.TabIndex = 3;
            this.tpRepairs.Text = "Repairs";
            this.tpRepairs.UseVisualStyleBackColor = true;
            // 
            // txtSearchRepair
            // 
            this.txtSearchRepair.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearchRepair.BackColor = System.Drawing.Color.DodgerBlue;
            this.txtSearchRepair.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchRepair.ForeColor = System.Drawing.Color.AliceBlue;
            this.txtSearchRepair.Location = new System.Drawing.Point(250, 303);
            this.txtSearchRepair.Name = "txtSearchRepair";
            this.txtSearchRepair.Size = new System.Drawing.Size(182, 22);
            this.txtSearchRepair.TabIndex = 29;
            this.txtSearchRepair.Text = "Search!";
            this.txtSearchRepair.TextChanged += new System.EventHandler(this.txtSearchRepair_TextChanged);
            // 
            // btnAddNewRepairInfo
            // 
            this.btnAddNewRepairInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddNewRepairInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddNewRepairInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnAddNewRepairInfo.FlatAppearance.BorderSize = 2;
            this.btnAddNewRepairInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNewRepairInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewRepairInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnAddNewRepairInfo.Location = new System.Drawing.Point(4, 303);
            this.btnAddNewRepairInfo.Name = "btnAddNewRepairInfo";
            this.btnAddNewRepairInfo.Size = new System.Drawing.Size(78, 25);
            this.btnAddNewRepairInfo.TabIndex = 17;
            this.btnAddNewRepairInfo.Text = "Add New +";
            this.btnAddNewRepairInfo.UseVisualStyleBackColor = false;
            this.btnAddNewRepairInfo.Click += new System.EventHandler(this.btnAddNewRepairInfo_Click);
            // 
            // btnUpdateRepairInfo
            // 
            this.btnUpdateRepairInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdateRepairInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateRepairInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateRepairInfo.FlatAppearance.BorderSize = 2;
            this.btnUpdateRepairInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateRepairInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateRepairInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnUpdateRepairInfo.Location = new System.Drawing.Point(85, 303);
            this.btnUpdateRepairInfo.Name = "btnUpdateRepairInfo";
            this.btnUpdateRepairInfo.Size = new System.Drawing.Size(78, 25);
            this.btnUpdateRepairInfo.TabIndex = 18;
            this.btnUpdateRepairInfo.Text = "Update";
            this.btnUpdateRepairInfo.UseVisualStyleBackColor = false;
            this.btnUpdateRepairInfo.Click += new System.EventHandler(this.btnUpdateRepairInfo_Click);
            // 
            // btnDeleteRepairInfo
            // 
            this.btnDeleteRepairInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeleteRepairInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDeleteRepairInfo.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteRepairInfo.FlatAppearance.BorderSize = 2;
            this.btnDeleteRepairInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteRepairInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteRepairInfo.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnDeleteRepairInfo.Location = new System.Drawing.Point(166, 303);
            this.btnDeleteRepairInfo.Name = "btnDeleteRepairInfo";
            this.btnDeleteRepairInfo.Size = new System.Drawing.Size(78, 25);
            this.btnDeleteRepairInfo.TabIndex = 19;
            this.btnDeleteRepairInfo.Text = "Delete -";
            this.btnDeleteRepairInfo.UseVisualStyleBackColor = false;
            this.btnDeleteRepairInfo.Click += new System.EventHandler(this.btnDeleteRepairInfo_Click);
            // 
            // dgRepairs
            // 
            this.dgRepairs.AllowUserToAddRows = false;
            this.dgRepairs.AllowUserToDeleteRows = false;
            this.dgRepairs.AllowUserToOrderColumns = true;
            this.dgRepairs.AutoGenerateColumns = false;
            this.dgRepairs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgRepairs.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dgRepairs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRepairs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RepairID,
            this.dataGridViewTextBoxColumn4,
            this.ReceiptNum,
            this.RepairDate,
            this.RepairPerformed,
            this.ShopInfo,
            this.mileageDataGridViewTextBoxColumn3,
            this.totalCostDataGridViewTextBoxColumn1});
            this.dgRepairs.DataSource = this.repairBindingSource;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgRepairs.DefaultCellStyle = dataGridViewCellStyle19;
            this.dgRepairs.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgRepairs.Location = new System.Drawing.Point(3, 3);
            this.dgRepairs.Name = "dgRepairs";
            this.dgRepairs.ReadOnly = true;
            this.dgRepairs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgRepairs.Size = new System.Drawing.Size(743, 294);
            this.dgRepairs.TabIndex = 1;
            // 
            // RepairID
            // 
            this.RepairID.DataPropertyName = "RepairID";
            this.RepairID.HeaderText = "Repair ID";
            this.RepairID.Name = "RepairID";
            this.RepairID.ReadOnly = true;
            this.RepairID.Width = 87;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "UnitNum";
            this.dataGridViewTextBoxColumn4.HeaderText = "Unit #";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 58;
            // 
            // ReceiptNum
            // 
            this.ReceiptNum.DataPropertyName = "ReceiptNum";
            this.ReceiptNum.HeaderText = "Receipt #";
            this.ReceiptNum.Name = "ReceiptNum";
            this.ReceiptNum.ReadOnly = true;
            this.ReceiptNum.Width = 88;
            // 
            // RepairDate
            // 
            this.RepairDate.DataPropertyName = "RepairDate";
            this.RepairDate.HeaderText = "Repair Date";
            this.RepairDate.Name = "RepairDate";
            this.RepairDate.ReadOnly = true;
            this.RepairDate.Width = 102;
            // 
            // RepairPerformed
            // 
            this.RepairPerformed.DataPropertyName = "RepairPerformed";
            dataGridViewCellStyle15.NullValue = null;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.RepairPerformed.DefaultCellStyle = dataGridViewCellStyle15;
            this.RepairPerformed.HeaderText = "Repair Performed";
            this.RepairPerformed.Name = "RepairPerformed";
            this.RepairPerformed.ReadOnly = true;
            this.RepairPerformed.Width = 136;
            // 
            // ShopInfo
            // 
            this.ShopInfo.DataPropertyName = "ShopInfo";
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ShopInfo.DefaultCellStyle = dataGridViewCellStyle16;
            this.ShopInfo.HeaderText = "Shop Information";
            this.ShopInfo.Name = "ShopInfo";
            this.ShopInfo.ReadOnly = true;
            this.ShopInfo.Width = 131;
            // 
            // mileageDataGridViewTextBoxColumn3
            // 
            this.mileageDataGridViewTextBoxColumn3.DataPropertyName = "Mileage";
            dataGridViewCellStyle17.Format = "N0";
            dataGridViewCellStyle17.NullValue = null;
            this.mileageDataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle17;
            this.mileageDataGridViewTextBoxColumn3.HeaderText = "Mileage";
            this.mileageDataGridViewTextBoxColumn3.Name = "mileageDataGridViewTextBoxColumn3";
            this.mileageDataGridViewTextBoxColumn3.ReadOnly = true;
            this.mileageDataGridViewTextBoxColumn3.Width = 82;
            // 
            // totalCostDataGridViewTextBoxColumn1
            // 
            this.totalCostDataGridViewTextBoxColumn1.DataPropertyName = "TotalCost";
            dataGridViewCellStyle18.Format = "C2";
            dataGridViewCellStyle18.NullValue = null;
            this.totalCostDataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle18;
            this.totalCostDataGridViewTextBoxColumn1.HeaderText = "Total Cost";
            this.totalCostDataGridViewTextBoxColumn1.Name = "totalCostDataGridViewTextBoxColumn1";
            this.totalCostDataGridViewTextBoxColumn1.ReadOnly = true;
            this.totalCostDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.totalCostDataGridViewTextBoxColumn1.Width = 90;
            // 
            // repairBindingSource
            // 
            this.repairBindingSource.DataMember = "Repair";
            this.repairBindingSource.DataSource = this.ezFleetRepair;
            // 
            // ezFleetRepair
            // 
            this.ezFleetRepair.DataSetName = "ezFleetRepair";
            this.ezFleetRepair.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblLoggedInAs
            // 
            this.lblLoggedInAs.AutoSize = true;
            this.lblLoggedInAs.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblLoggedInAs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblLoggedInAs.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoggedInAs.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lblLoggedInAs.Location = new System.Drawing.Point(130, 9);
            this.lblLoggedInAs.Name = "lblLoggedInAs";
            this.lblLoggedInAs.Size = new System.Drawing.Size(0, 19);
            this.lblLoggedInAs.TabIndex = 0;
            // 
            // driverRosterTableAdapter
            // 
            this.driverRosterTableAdapter.ClearBeforeFill = true;
            // 
            // fuelTableAdapter
            // 
            this.fuelTableAdapter.ClearBeforeFill = true;
            // 
            // equipmentMaintenanceTableAdapter
            // 
            this.equipmentMaintenanceTableAdapter.ClearBeforeFill = true;
            // 
            // equipmentInventoryTableAdapter
            // 
            this.equipmentInventoryTableAdapter.ClearBeforeFill = true;
            // 
            // repairTableAdapter
            // 
            this.repairTableAdapter.ClearBeforeFill = true;
            // 
            // frmEzFleetDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 487);
            this.Controls.Add(this.lblLoggedInAs);
            this.Controls.Add(this.tcDashboard);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblLogo);
            this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmEzFleetDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ezFleet - Dashboard";
            this.Load += new System.EventHandler(this.frmEzFleetDashboard_Load);
            this.tcDashboard.ResumeLayout(false);
            this.tpDriverRoster.ResumeLayout(false);
            this.tpDriverRoster.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDriverRoster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.driverRosterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ezFleetRoster)).EndInit();
            this.tpEquipmentInventory.ResumeLayout(false);
            this.tpEquipmentInventory.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgEquipmentInventory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipmentInventoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ezFleetInventory)).EndInit();
            this.tpEquipmentMaintenance.ResumeLayout(false);
            this.tpEquipmentMaintenance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgEquipmentMaintenace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipmentMaintenanceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ezFleetMaintenance)).EndInit();
            this.tpFuel.ResumeLayout(false);
            this.tpFuel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFuel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fuelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ezFleetFuel)).EndInit();
            this.tpRepairs.ResumeLayout(false);
            this.tpRepairs.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRepairs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repairBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ezFleetRepair)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tcDashboard;
        private System.Windows.Forms.TabPage tpDriverRoster;
        private System.Windows.Forms.TabPage tpEquipmentInventory;
        private System.Windows.Forms.TabPage tpEquipmentMaintenance;
        private System.Windows.Forms.TabPage tpFuel;
        private System.Windows.Forms.TabPage tpRepairs;
        private System.Windows.Forms.DataGridView dgDriverRoster;
        private System.Windows.Forms.DataGridView dgEquipmentInventory;
        private System.Windows.Forms.DataGridView dgEquipmentMaintenace;
        private System.Windows.Forms.DataGridView dgFuel;
        private System.Windows.Forms.DataGridView dgRepairs;
        private System.Windows.Forms.Button btnAddNewEquipmentInfo;
        private System.Windows.Forms.Button btnUpdateEquipmentInfo;
        private System.Windows.Forms.Button btnDeleteEquipmentInfo;
        private System.Windows.Forms.Label lblLoggedInAs;
        private System.Windows.Forms.TextBox txtSearchDrivers;
        private System.Windows.Forms.Button btnAddNewDriverInfo;
        private System.Windows.Forms.Button btnUpdateDriverInfo;
        private System.Windows.Forms.Button btnDeleteDriverInfo;
        private System.Windows.Forms.Button btnAddNewMaintenanceInfo;
        private System.Windows.Forms.Button btnUpdateEquipmentMaintenanceInfo;
        private System.Windows.Forms.Button btnDeleteEquipmentMaintenanceInfo;
        private System.Windows.Forms.Button btnAddNewFuelInfo;
        private System.Windows.Forms.Button btnUpdateFuelInfo;
        private System.Windows.Forms.Button btnDeleteFuelInfo;
        private System.Windows.Forms.Button btnAddNewRepairInfo;
        private System.Windows.Forms.Button btnUpdateRepairInfo;
        private System.Windows.Forms.Button btnDeleteRepairInfo;
        private System.Windows.Forms.TextBox txtSearchInventory;
        private ezFleetRepair ezFleetRepair;
        private ezFleetFuelTableAdapters.FuelTableAdapter fuelTableAdapter;
        private ezFleetMaintenanceTableAdapters.EquipmentMaintenanceTableAdapter equipmentMaintenanceTableAdapter;
        private ezFleetInventoryTableAdapters.EquipmentInventoryTableAdapter equipmentInventoryTableAdapter;
        private ezFleetRosterTableAdapters.DriverRosterTableAdapter driverRosterTableAdapter;
        private ezFleetFuel ezFleetFuel;
        private System.Windows.Forms.BindingSource fuelBindingSource;
        private ezFleetMaintenance ezFleetMaintenance;
        private System.Windows.Forms.BindingSource equipmentMaintenanceBindingSource;
        private ezFleetInventory ezFleetInventory;
        private System.Windows.Forms.BindingSource equipmentInventoryBindingSource;
        private ezFleetRoster ezFleetRoster;
        private System.Windows.Forms.BindingSource driverRosterBindingSource;
        private ezFleetRepairTableAdapters.RepairTableAdapter repairTableAdapter;
        private System.Windows.Forms.BindingSource repairBindingSource;
        private System.Windows.Forms.TextBox txtSearchMaintenance;
        private System.Windows.Forms.TextBox txtSearchFuel;
        private System.Windows.Forms.TextBox txtSearchRepair;
        private System.Windows.Forms.DataGridViewTextBoxColumn rosterIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn driverNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn homeAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hireDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maintenanceIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn VinNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn equipmentTypeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn mileageDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicedPerformedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nextServiceDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fuelIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn mileageDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn fuelDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TransactionNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn pricePerGallonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gallonsFueledDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalCostDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fuelLocationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn RepairID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReceiptNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn RepairDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn RepairPerformed;
        private System.Windows.Forms.DataGridViewTextBoxColumn ShopInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn mileageDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalCostDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn equipmentIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn equipmentTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn makeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mileageDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchaseDateDataGridViewTextBoxColumn;
    }
}