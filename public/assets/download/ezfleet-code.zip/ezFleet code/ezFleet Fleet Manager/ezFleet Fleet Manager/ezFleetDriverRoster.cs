﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace ezFleet_Fleet_Manager
{
    public partial class frmEzFleetDashboard : Form
    {
        private readonly ezFleetDataContext ezFleetDb;
        
        public frmEzFleetDashboard(string userName)
        {
            InitializeComponent();
            ezFleetDb = new ezFleetDataContext();
            lblLoggedInAs.Text = userName;

        }

        private void btnAddNewDriverInfo_Click(object sender, EventArgs e)
        {
            frmAddNewDriver addNewDriver = new frmAddNewDriver();
            addNewDriver.MdiParent = this.MdiParent;
            addNewDriver.ShowDialog();
            AddToDataGrid();

        }

        private void btnUpdateDriverInfo_Click(object sender, EventArgs e)
        {

            var driverId = (int)dgDriverRoster.SelectedRows[0].Cells[0].Value;
            var driverToUpdate = ezFleetDb.DriverRosters.FirstOrDefault(d => d.RosterID == driverId);

            frmUpdateDriver updateDriver = new frmUpdateDriver(driverToUpdate);
            updateDriver.MdiParent = this.MdiParent;
            updateDriver.ShowDialog();
            AddToDataGrid();
        }

        private void btnDeleteDriverInfo_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Delete?", "Delete - Driver Record", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                frmDelDrivers deleteDriver = new frmDelDrivers();
                deleteDriver.MdiParent = this.MdiParent;
                deleteDriver.ShowDialog();

                var rosterID = (int)dgDriverRoster.SelectedRows[0].Cells[0].Value;
                var driver = ezFleetDb.DriverRosters.FirstOrDefault(d => d.RosterID == rosterID);
                ezFleetDb.DriverRosters.DeleteOnSubmit(driver);
                ezFleetDb.SubmitChanges();

                AddToDataGrid();
            }
        }

        private void btnAddNewEquipmentInfo_Click(object sender, EventArgs e)
        {
            frmAddEquipment addEquipment = new frmAddEquipment();
            addEquipment.MdiParent = this.MdiParent;
            addEquipment.ShowDialog();
            AddToDataGrid();
        }

        private void btnUpdateEquipmentInfo_Click(object sender, EventArgs e)
        {
            var equipmentID = (int)dgEquipmentInventory.SelectedRows[0].Cells[0].Value;
            var equipmentToUpdate = ezFleetDb.EquipmentInventories.FirstOrDefault(eq => eq.EquipmentID == equipmentID);

            frmUpdateEquipment updateEquipment = new frmUpdateEquipment(equipmentToUpdate);
            updateEquipment.MdiParent = this.MdiParent;
            updateEquipment.ShowDialog();
            AddToDataGrid();
        }

        private void btnDeleteEquipmentInfo_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Delete?", "Delete - Inventory Record", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                frmDeleteEquipment deleteEquipment = new frmDeleteEquipment();
                deleteEquipment.MdiParent = this.MdiParent;
                deleteEquipment.ShowDialog();

                var equipmentID = (int)dgEquipmentInventory.SelectedRows[0].Cells[0].Value;
                var equipment = ezFleetDb.EquipmentInventories.FirstOrDefault(eq => eq.EquipmentID == equipmentID);
                ezFleetDb.EquipmentInventories.DeleteOnSubmit(equipment);
                ezFleetDb.SubmitChanges();
                AddToDataGrid();
            }
        }

        private void btnAddNewMaintenanceInfo_Click(object sender, EventArgs e)
        {
            frmAddMaintenance addMaintenance = new frmAddMaintenance();
            addMaintenance.MdiParent = this.MdiParent;
            addMaintenance.ShowDialog();
            AddToDataGrid();
        }

        private void btnUpdateEquipmentMaintenanceInfo_Click(object sender, EventArgs e)
        {
            var maintenanceID = (int)dgEquipmentMaintenace.SelectedRows[0].Cells[0].Value;
            var maintenanceToUpdate = ezFleetDb.EquipmentMaintenances.FirstOrDefault(eq => eq.MaintenanceID == maintenanceID);

            frmUpdateMaintenance updateMaintenance = new frmUpdateMaintenance(maintenanceToUpdate);
            updateMaintenance.MdiParent = this.MdiParent;
            updateMaintenance.ShowDialog();
            AddToDataGrid();

        }

        private void btnDeleteEquipmentMaintenanceInfo_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Delete?", "Delete - Maintenance Record", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                frmDeleteMaintenance deleteMaintenance = new frmDeleteMaintenance();
                deleteMaintenance.MdiParent = this.MdiParent;
                deleteMaintenance.ShowDialog();

                var maintenanceID = (int)dgEquipmentMaintenace.SelectedRows[0].Cells[0].Value;
                var maintenance = ezFleetDb.EquipmentMaintenances.FirstOrDefault(m => m.MaintenanceID == maintenanceID);
                ezFleetDb.EquipmentMaintenances.DeleteOnSubmit(maintenance);
                ezFleetDb.SubmitChanges();
                AddToDataGrid();
            }
        }

        private void btnAddNewFuelInfo_Click(object sender, EventArgs e)
        {
            frmAddFuel addFuel = new frmAddFuel();
            addFuel.MdiParent = this.MdiParent;
            addFuel.ShowDialog();
            AddToDataGrid();

        }

        private void btnUpdateFuelInfo_Click(object sender, EventArgs e)
        {
            var fuelID = (int)dgFuel.SelectedRows[0].Cells[0].Value;
            var fuelToUpdate = ezFleetDb.Fuels.FirstOrDefault(f => f.FuelID == fuelID);

            frmUpdateFuel updateFuel = new frmUpdateFuel(fuelToUpdate);
            updateFuel.MdiParent = this.MdiParent;
            updateFuel.ShowDialog();
            AddToDataGrid();
        }

        private void btnDeleteFuelInfo_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Delete?", "Delete - Fuel Record", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                frmDeleteFuel deleteFuel = new frmDeleteFuel();
                deleteFuel.MdiParent = this.MdiParent;
                deleteFuel.ShowDialog();

                var fuelID = (int)dgFuel.SelectedRows[0].Cells[0].Value;
                var fuel = ezFleetDb.Fuels.FirstOrDefault(f => f.FuelID == fuelID);
                ezFleetDb.Fuels.DeleteOnSubmit(fuel);
                ezFleetDb.SubmitChanges();
                AddToDataGrid();

            }
        }

        private void btnAddNewRepairInfo_Click(object sender, EventArgs e)
        {
            frmAddRepair addRepair = new frmAddRepair();
            addRepair.MdiParent = this.MdiParent;
            addRepair.ShowDialog();
            AddToDataGrid();
        }

        private void btnUpdateRepairInfo_Click(object sender, EventArgs e)
        {
            var repairID = (int)dgRepairs.SelectedRows[0].Cells[0].Value;
            var repairToUpdate = ezFleetDb.Repairs.FirstOrDefault(r => r.RepairID == repairID);

            frmUpdateRepair updateRepair = new frmUpdateRepair(repairToUpdate);
            updateRepair.MdiParent = this.MdiParent;
            updateRepair.ShowDialog();
            AddToDataGrid();
        }

        private void btnDeleteRepairInfo_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Delete?", "Delete - Repair Record", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                frmDeleteRepair deleteRepair = new frmDeleteRepair();
                deleteRepair.MdiParent = this.MdiParent;
                deleteRepair.ShowDialog();

                var repairID = (int)dgRepairs.SelectedRows[0].Cells[0].Value;
                var repair = ezFleetDb.Repairs.FirstOrDefault(r => r.RepairID == repairID);
                ezFleetDb.Repairs.DeleteOnSubmit(repair);
                ezFleetDb.SubmitChanges();
                AddToDataGrid();
            }
        }

        private void frmEzFleetDashboard_Load(object sender, EventArgs e)
        {

            AddToDataGrid();

        }

        private void AddToDataGrid()
        {
            this.driverRosterTableAdapter.Fill(this.ezFleetRoster.DriverRoster);
            this.repairTableAdapter.Fill(this.ezFleetRepair.Repair);
            this.fuelTableAdapter.Fill(this.ezFleetFuel.Fuel);
            this.equipmentMaintenanceTableAdapter.Fill(this.ezFleetMaintenance.EquipmentMaintenance);
            this.equipmentInventoryTableAdapter.Fill(this.ezFleetInventory.EquipmentInventory);
        }

        private void btnSearchMaintenance_Click(object sender, EventArgs e)
        {

        }

        private void btnSearchFuel_Click(object sender, EventArgs e)
        {

        }

        private void txtSearchRepair_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSearchRepair.Text))
            {
                repairBindingSource.Filter = String.Format(
                    "ShopInfo LIKE '%{0}%'" +
                    " OR ReceiptNum LIKE '%{0}%'" +
                    " OR RepairPerformed LIKE '%{0}%'" +
                    "OR UnitNum LIKE '%{0}%'"
                    , txtSearchRepair.Text);
                dgRepairs.Refresh();
            }
            else
            {
                repairBindingSource.Filter = string.Empty;

            }
        }

        private void txtSearchDrivers_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSearchDrivers.Text))
            {
                driverRosterBindingSource.Filter = string.Format(
                    "DriverName LIKE '%{0}%'" +
                    " OR HomeAddress LIKE '%{0}%'" +
                    " OR PhoneNumber LIKE '%{0}%'" +
                    " OR EmailAddress LIKE '%{0}%'"
                    , txtSearchDrivers.Text);
                dgDriverRoster.Refresh();
            }
            else
            {
                driverRosterBindingSource.Filter = string.Empty;

            }
        }

        private void txtSearchInventory_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSearchInventory.Text))
            {
                equipmentInventoryBindingSource.Filter = string.Format(
                    "EquipmentType LIKE '%{0}%'" +
                    " OR Color LIKE '%{0}%'" +
                    " OR Make LIKE '%{0}%'" +
                    " OR UnitNum LIKE '%{0}%'" +
                    " OR VinNum LIKE '%{0}%'"
                    , txtSearchInventory.Text);

                dgEquipmentInventory.Refresh();
            }
            else
            {
                equipmentInventoryBindingSource.Filter = string.Empty;

            }
        }

        private void txtSearchMaintenance_TextChanged(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(txtSearchMaintenance.Text))
            {
                equipmentMaintenanceBindingSource.Filter = String.Format(
                    "EquipmentType LIKE '%{0}%'" +
                    " OR VinNum LIKE '%{0}%'" +
                    " OR UnitNum LIKE '%{0}%'" 
                  
                    , txtSearchMaintenance.Text);
                dgEquipmentMaintenace.Refresh();
            }
            else
            {
                equipmentMaintenanceBindingSource.Filter = string.Empty;

            }
        }

        private void txtSearchFuel_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSearchFuel.Text))
            {
                fuelBindingSource.Filter = String.Format(
                    "TransactionNum LIKE '%{0}%'" +
                    " OR FuelLocation LIKE '%{0}%'" +
                    " OR UnitNum LIKE '%{0}%'"
                    , txtSearchFuel.Text);
                dgFuel.Refresh();
            }
            else
            {
                fuelBindingSource.Filter = string.Empty;

            }
        }
    }
}

