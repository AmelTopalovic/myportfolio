﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;

//namespace ezFleet_Fleet_Manager
//{
//    public partial class frmDeleteDriver : Form
//    {
       

//        public frmDeleteDriver()
//        {
//            btnDeleteDriver.Enabled = false;
//            InitializeComponent();
           
//        }

//        private void btnDeleteDriver_Click(object sender, EventArgs e)
//        {
//            int adminPass = 8008135;

//            if(adminPass != int.Parse(txtAdminPass.Text))
//            {
//                lblError.Text = "ADMIN PIN NOT VALID";
                
//            }
//            else
//            {
//                btnDeleteDriver.Enabled = true;

//                Close();
//            }



//        }
//    }
//}
