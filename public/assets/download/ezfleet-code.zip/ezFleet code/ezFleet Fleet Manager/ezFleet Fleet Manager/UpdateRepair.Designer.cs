﻿namespace ezFleet_Fleet_Manager
{
    partial class frmUpdateRepair
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.txtUpdateRepairTotalCost = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtUpdateShopInformation = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnUpdateRepair = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtUpdateRepairPerformed = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUpdateRepairMileage = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUpdateRepairUnitNum = new System.Windows.Forms.TextBox();
            this.lblRepairID = new System.Windows.Forms.Label();
            this.txtUpdateRepairReceipt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpUpdateRepairDate = new System.Windows.Forms.DateTimePicker();
            this.lblError = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(252, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 98;
            this.label3.Text = "Total Cost ($)";
            // 
            // txtUpdateRepairTotalCost
            // 
            this.txtUpdateRepairTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateRepairTotalCost.Location = new System.Drawing.Point(255, 127);
            this.txtUpdateRepairTotalCost.Name = "txtUpdateRepairTotalCost";
            this.txtUpdateRepairTotalCost.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateRepairTotalCost.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(255, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 16);
            this.label6.TabIndex = 96;
            this.label6.Text = "Shop Information";
            // 
            // txtUpdateShopInformation
            // 
            this.txtUpdateShopInformation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateShopInformation.Location = new System.Drawing.Point(255, 33);
            this.txtUpdateShopInformation.Multiline = true;
            this.txtUpdateShopInformation.Name = "txtUpdateShopInformation";
            this.txtUpdateShopInformation.Size = new System.Drawing.Size(202, 72);
            this.txtUpdateShopInformation.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(12, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 16);
            this.label9.TabIndex = 92;
            this.label9.Text = "Receipt #";
            // 
            // btnUpdateRepair
            // 
            this.btnUpdateRepair.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdateRepair.FlatAppearance.BorderSize = 2;
            this.btnUpdateRepair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateRepair.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateRepair.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdateRepair.Location = new System.Drawing.Point(15, 225);
            this.btnUpdateRepair.Name = "btnUpdateRepair";
            this.btnUpdateRepair.Size = new System.Drawing.Size(199, 40);
            this.btnUpdateRepair.TabIndex = 7;
            this.btnUpdateRepair.Text = "Update";
            this.btnUpdateRepair.UseVisualStyleBackColor = true;
            this.btnUpdateRepair.Click += new System.EventHandler(this.btnUpdateRepair_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(15, 128);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 16);
            this.label7.TabIndex = 89;
            this.label7.Text = "Repair Performed";
            // 
            // txtUpdateRepairPerformed
            // 
            this.txtUpdateRepairPerformed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateRepairPerformed.Location = new System.Drawing.Point(15, 144);
            this.txtUpdateRepairPerformed.Multiline = true;
            this.txtUpdateRepairPerformed.Name = "txtUpdateRepairPerformed";
            this.txtUpdateRepairPerformed.Size = new System.Drawing.Size(202, 72);
            this.txtUpdateRepairPerformed.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(15, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 16);
            this.label1.TabIndex = 87;
            this.label1.Text = "Mileage";
            // 
            // txtUpdateRepairMileage
            // 
            this.txtUpdateRepairMileage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateRepairMileage.Location = new System.Drawing.Point(15, 95);
            this.txtUpdateRepairMileage.Name = "txtUpdateRepairMileage";
            this.txtUpdateRepairMileage.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateRepairMileage.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(252, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 100;
            this.label2.Text = "Unit #";
            // 
            // txtUpdateRepairUnitNum
            // 
            this.txtUpdateRepairUnitNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateRepairUnitNum.Location = new System.Drawing.Point(255, 179);
            this.txtUpdateRepairUnitNum.Name = "txtUpdateRepairUnitNum";
            this.txtUpdateRepairUnitNum.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateRepairUnitNum.TabIndex = 5;
            // 
            // lblRepairID
            // 
            this.lblRepairID.AutoSize = true;
            this.lblRepairID.Location = new System.Drawing.Point(255, 251);
            this.lblRepairID.Name = "lblRepairID";
            this.lblRepairID.Size = new System.Drawing.Size(0, 13);
            this.lblRepairID.TabIndex = 101;
            this.lblRepairID.Visible = false;
            // 
            // txtUpdateRepairReceipt
            // 
            this.txtUpdateRepairReceipt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUpdateRepairReceipt.Location = new System.Drawing.Point(15, 36);
            this.txtUpdateRepairReceipt.Name = "txtUpdateRepairReceipt";
            this.txtUpdateRepairReceipt.Size = new System.Drawing.Size(202, 20);
            this.txtUpdateRepairReceipt.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(255, 206);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 16);
            this.label4.TabIndex = 103;
            this.label4.Text = "Repair Date";
            // 
            // dtpUpdateRepairDate
            // 
            this.dtpUpdateRepairDate.Location = new System.Drawing.Point(255, 225);
            this.dtpUpdateRepairDate.Name = "dtpUpdateRepairDate";
            this.dtpUpdateRepairDate.Size = new System.Drawing.Size(200, 20);
            this.dtpUpdateRepairDate.TabIndex = 6;
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(221, 251);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(0, 13);
            this.lblError.TabIndex = 104;
            // 
            // frmUpdateRepair
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(471, 277);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.dtpUpdateRepairDate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtUpdateRepairReceipt);
            this.Controls.Add(this.lblRepairID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtUpdateRepairUnitNum);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtUpdateRepairTotalCost);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtUpdateShopInformation);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnUpdateRepair);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtUpdateRepairPerformed);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtUpdateRepairMileage);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmUpdateRepair";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update - Repair";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUpdateRepairTotalCost;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtUpdateShopInformation;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnUpdateRepair;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtUpdateRepairPerformed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUpdateRepairMileage;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUpdateRepairUnitNum;
        private System.Windows.Forms.Label lblRepairID;
        private System.Windows.Forms.TextBox txtUpdateRepairReceipt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpUpdateRepairDate;
        private System.Windows.Forms.Label lblError;
    }
}