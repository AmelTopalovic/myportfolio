﻿CREATE TABLE [dbo].[Fuel] (
    [Unit#]          INT NOT NULL,
    [Mileage]        INT             NULL,
    [GallonsFueled]  FLOAT (53)      NULL,
    [PricePerGallon] DECIMAL (18, 2) NULL,
    [TotalCost]      DECIMAL (18, 2) NULL,
    [FuelLocation]   NVARCHAR (MAX)  NULL,
    [Transaction#]   INT             NOT NULL, 
    [FuelDate] DATE NULL, 
    [FuelID] INT NOT NULL IDENTITY, 
    CONSTRAINT [PK_Fuel] PRIMARY KEY ([FuelID]) 
);

